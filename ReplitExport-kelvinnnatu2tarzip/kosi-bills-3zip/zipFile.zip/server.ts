import express from 'express';
import { createServer as createViteServer } from 'vite';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import jwt from 'jsonwebtoken';
import cookieParser from 'cookie-parser';
import csrf from 'csurf';
import crypto from 'crypto';
import nodemailer from 'nodemailer';
import webpush from 'web-push';

// Web Push Configuration
const vapidKeys = {
  publicKey: process.env.VAPID_PUBLIC_KEY || '',
  privateKey: process.env.VAPID_PRIVATE_KEY || '',
};

if (vapidKeys.publicKey && vapidKeys.privateKey) {
  webpush.setVapidDetails(
    'mailto:support@kosibills.com',
    vapidKeys.publicKey,
    vapidKeys.privateKey
  );
}

// Email Transporter
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.example.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: process.env.SMTP_PORT === '465',
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

const sendEmail = async (to: string, subject: string, html: string) => {
  if (!process.env.SMTP_USER || !process.env.SMTP_PASS) {
    console.warn('SMTP credentials not configured. Skipping email send.');
    return;
  }
  try {
    await transporter.sendMail({
      from: process.env.SMTP_FROM || '"Kosi Bills" <noreply@kosibills.com>',
      to,
      subject,
      html,
    });
  } catch (error) {
    console.error('Error sending email:', error);
  }
};

console.log('Initializing database...');
const db = new Database('kosi_bills.db');
db.pragma('journal_mode = WAL'); // Use WAL mode for better concurrency and corruption resistance

// Initialize Database
console.log('Creating tables...');
db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      email TEXT UNIQUE,
      phone TEXT,
      password TEXT,
      balance REAL DEFAULT 0,
      tier TEXT DEFAULT 'Basic',
      is_live_mode INTEGER DEFAULT 0,
      is_biometric_enabled INTEGER DEFAULT 0,
      pin TEXT DEFAULT '1234',
      profile_photo TEXT,
      account_status TEXT DEFAULT 'active',
      kyc_level INTEGER DEFAULT 1,
      currency TEXT DEFAULT 'NGN',
      is_agent INTEGER DEFAULT 0,
      is_admin INTEGER DEFAULT 0,
      referral_code TEXT,
      hide_balance INTEGER DEFAULT 0,
      session_token TEXT,
      is_customer_care INTEGER DEFAULT 0,
      daily_transfer_limit REAL DEFAULT 50000,
      daily_withdrawal_limit REAL DEFAULT 50000,
      total_referred INTEGER DEFAULT 0,
      bvn TEXT,
      last_login_at TEXT,
      two_factor_enabled INTEGER DEFAULT 0,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
  `);

  try {
    db.exec('ALTER TABLE users ADD COLUMN daily_transfer_limit REAL DEFAULT 50000;');
  } catch(e) { /* ignore duplicate column error */ }
  try {
    db.exec('ALTER TABLE users ADD COLUMN daily_withdrawal_limit REAL DEFAULT 50000;');
  } catch(e) { /* ignore duplicate column error */ }
  try {
    db.exec('ALTER TABLE users ADD COLUMN total_referred INTEGER DEFAULT 0;');
  } catch(e) { /* ignore duplicate column error */ }
  try {
    db.exec('ALTER TABLE users ADD COLUMN bvn TEXT;');
  } catch(e) { /* ignore duplicate column error */ }
  try {
    db.exec('ALTER TABLE users ADD COLUMN last_login_at TEXT;');
  } catch(e) { /* ignore duplicate column error */ }
  try {
    db.exec('ALTER TABLE users ADD COLUMN two_factor_enabled INTEGER DEFAULT 0;');
  } catch(e) { /* ignore duplicate column error */ }
  try {
    db.exec('ALTER TABLE users ADD COLUMN is_email_verified INTEGER DEFAULT 0;');
  } catch(e) { /* ignore duplicate column error */ }
  try {
    db.exec('ALTER TABLE users ADD COLUMN email_receipts_enabled INTEGER DEFAULT 1;');
  } catch(e) { /* ignore duplicate column error */ }
  try {
    db.exec('ALTER TABLE users ADD COLUMN verification_token TEXT;');
  } catch(e) { /* ignore duplicate column error */ }
  try {
    db.exec('ALTER TABLE users ADD COLUMN reset_token TEXT;');
  } catch(e) { /* ignore duplicate column error */ }
  try {
    db.exec('ALTER TABLE users ADD COLUMN reset_token_expiry TEXT;');
  } catch(e) { /* ignore duplicate column error */ }

  db.exec(`
    CREATE TABLE IF NOT EXISTS transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      type TEXT,
      description TEXT,
      amount REAL,
      date TEXT,
      status TEXT,
      tx_ref TEXT,
      category TEXT,
      balance_after REAL,
      sub_wallet_id INTEGER,
      metadata TEXT,
      FOREIGN KEY(user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS sub_wallets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      owner_id INTEGER,
      name TEXT,
      balance REAL DEFAULT 0,
      FOREIGN KEY(owner_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS sub_wallet_members (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sub_wallet_id INTEGER,
      user_id INTEGER,
      allowed_categories TEXT,
      FOREIGN KEY(sub_wallet_id) REFERENCES sub_wallets(id),
      FOREIGN KEY(user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS rewards (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT,
      points INTEGER,
      icon TEXT,
      color TEXT,
      bg TEXT
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      title TEXT,
      message TEXT,
      date TEXT,
      read INTEGER DEFAULT 0,
      type TEXT,
      transaction_id INTEGER,
      FOREIGN KEY(user_id) REFERENCES users(id)
    );
    
    CREATE TABLE IF NOT EXISTS support_tickets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      subject TEXT,
      status TEXT DEFAULT 'open',
      created_at TEXT,
      updated_at TEXT,
      FOREIGN KEY(user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS support_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ticket_id INTEGER,
      sender_id INTEGER,
      sender_type TEXT, -- 'user', 'ai', 'agent'
      message TEXT,
      created_at TEXT,
      FOREIGN KEY(ticket_id) REFERENCES support_tickets(id)
    );

    CREATE TABLE IF NOT EXISTS system_settings (
      key TEXT PRIMARY KEY,
      value TEXT
    );

    INSERT OR IGNORE INTO system_settings (key, value) VALUES 
      ('transfer_fee', '10'),
      ('min_withdrawal', '1000'),
      ('maintenance_mode', 'false');

    CREATE TABLE IF NOT EXISTS admin_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      admin_id INTEGER,
      action TEXT,
      target_id INTEGER,
      details TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(admin_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS beneficiaries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      name TEXT,
      phone TEXT,
      service_type TEXT,
      provider TEXT,
      FOREIGN KEY(user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS push_subscriptions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      subscription TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id)
    );

    -- Create indexes for performance with large datasets
    CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
    CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);
    CREATE INDEX IF NOT EXISTS idx_users_role ON users(is_agent, is_admin, is_customer_care);
    CREATE INDEX IF NOT EXISTS idx_users_created_at ON users(created_at);
    
    CREATE INDEX IF NOT EXISTS idx_transactions_user_id ON transactions(user_id);
    CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(date);
    CREATE INDEX IF NOT EXISTS idx_transactions_type ON transactions(type);
    CREATE INDEX IF NOT EXISTS idx_transactions_status ON transactions(status);
  `);

  db.exec(`
    INSERT OR IGNORE INTO rewards (id, title, points, icon, color, bg) VALUES 
    (1, '10% Off Airtime', 500, 'Star', 'text-amber-500', 'bg-amber-100 dark:bg-amber-900/30'),
    (2, 'Free 1GB Data', 1200, 'Gift', 'text-emerald-500', 'bg-emerald-100 dark:bg-emerald-900/30'),
    (3, '₦500 Cashback', 2000, 'Award', 'text-blue-500', 'bg-blue-100 dark:bg-blue-900/30'),
    (4, 'Premium Upgrade', 5000, 'Star', 'text-purple-500', 'bg-purple-100 dark:bg-purple-900/30');
  `);

  // Migrations: Add new columns if they don't exist
  const migrations = [
    'ALTER TABLE users ADD COLUMN phone TEXT',
    'ALTER TABLE users ADD COLUMN pin TEXT DEFAULT "1234"',
    'ALTER TABLE users ADD COLUMN is_live_mode INTEGER DEFAULT 0',
    'ALTER TABLE users ADD COLUMN is_biometric_enabled INTEGER DEFAULT 0',
    'ALTER TABLE users ADD COLUMN profile_photo TEXT',
    'ALTER TABLE users ADD COLUMN account_status TEXT DEFAULT "active"',
    'ALTER TABLE users ADD COLUMN kyc_level INTEGER DEFAULT 1',
    'ALTER TABLE users ADD COLUMN currency TEXT DEFAULT "NGN"',
    'ALTER TABLE users ADD COLUMN is_agent INTEGER DEFAULT 0',
    'ALTER TABLE users ADD COLUMN is_admin INTEGER DEFAULT 0',
    'ALTER TABLE users ADD COLUMN referral_code TEXT',
    'ALTER TABLE users ADD COLUMN hide_balance INTEGER DEFAULT 0',
    'ALTER TABLE users ADD COLUMN is_customer_care INTEGER DEFAULT 0',
    'ALTER TABLE users ADD COLUMN created_at TEXT DEFAULT CURRENT_TIMESTAMP',
    'ALTER TABLE transactions ADD COLUMN tx_ref TEXT',
    'ALTER TABLE transactions ADD COLUMN category TEXT',
    'ALTER TABLE transactions ADD COLUMN balance_after REAL',
    'ALTER TABLE transactions ADD COLUMN sub_wallet_id INTEGER',
    'ALTER TABLE notifications ADD COLUMN transaction_id INTEGER'
  ];

  for (const migration of migrations) {
    try {
      db.exec(migration);
    } catch (e) {
      // Column already exists
    }
  }

  // Set admin
  try {
    db.prepare('UPDATE users SET is_admin = 1 WHERE email = ?').run('kelvinnnatu2@gmail.com');
    // Demote previous bootstrap admin if it exists
    db.prepare('UPDATE users SET is_admin = 0 WHERE email = ? AND email != ?').run('kelvinkossy03@gmail.com', 'kelvinnnatu2@gmail.com');
  } catch (e) {
    console.error('Failed to set admin:', e);
  }

  // Create unique index separately to handle potential duplicates gracefully
  try {
    // Clean up duplicates by appending ID to phone number
    db.exec(`
      UPDATE users 
      SET phone = phone || '_' || id 
      WHERE phone IS NOT NULL AND phone != '' 
      AND id NOT IN (
        SELECT MIN(id) FROM users 
        WHERE phone IS NOT NULL AND phone != '' 
        GROUP BY phone
      )
    `);
    db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_phone ON users(phone)');
  } catch (e) {
    console.error('Could not create unique index on phone:', e);
  }

  try {
    db.exec('ALTER TABLE users ADD COLUMN is_customer_care INTEGER DEFAULT 0');
  } catch (e) {
    // Column might already exist, ignore error
  }

  console.log('Database initialized successfully.');

const hashPassword = (password: string) => {
  return bcrypt.hashSync(password, 12); // Increased salt rounds to 12 for better security
};

const verifyPassword = (password: string, hash: string) => {
  return bcrypt.compareSync(password, hash);
};

const JWT_SECRET = process.env.JWT_SECRET || 'supersecret';

const processTransaction = db.transaction((userId: number, type: string, description: string, amount: number, date: string, status: string, category: string | null = null, subWalletId: number | null = null, txRef: string | null = null) => {
  const user = db.prepare('SELECT balance FROM users WHERE id = ?').get(userId) as any;
  if (!user) throw new Error('User not found');
  
  // Prevent negative balance for debits
  if (amount < 0 && user.balance < Math.abs(amount)) {
    throw new Error('Insufficient funds');
  }
  
  // 1. Update user balance
  db.prepare('UPDATE users SET balance = balance + ? WHERE id = ?').run(amount, userId);
  const newBalance = user.balance + amount;
  
  // 2. Insert transaction
  const insertTx = db.prepare('INSERT INTO transactions (user_id, type, description, amount, date, status, category, sub_wallet_id, tx_ref, balance_after) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
  insertTx.run(userId, type, description, amount, date, status, category, subWalletId, txRef, newBalance);

  // 3. Log transaction for admin with more details
  db.prepare('INSERT INTO admin_logs (action, target_id, details) VALUES (?, ?, ?)')
    .run('TRANSACTION_PROCESSED', userId, `Type: ${type}, Amount: ${amount}, Desc: ${description}, Status: ${status}, Ref: ${txRef}`);
  
  console.log(`[TRANSACTION] User ${userId}: ${type} of ${amount} - ${status}`);
});

const registerSchema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
  phone: z.string().min(10),
  password: z.string().min(6),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

const authenticateToken = (req: any, res: any, next: any) => {
  let token = req.cookies.token;
  if (!token && req.headers.authorization) {
    token = req.headers.authorization.split(' ')[1];
  }
  
  if (token == null) {
    return res.sendStatus(401);
  }

  jwt.verify(token, JWT_SECRET, (err: any, decoded: any) => {
    if (err) {
      console.error('JWT verification error:', err);
      return res.sendStatus(403);
    }
    
    console.log('Decoded token:', decoded);
    console.log('Cookies:', req.cookies);
    const stmt = db.prepare('SELECT session_token FROM users WHERE id = ?');
    const user = stmt.get(decoded.id) as any;
    
    if (!user || user.session_token !== decoded.session_token) {
      console.error('User not found or session token mismatch. User:', user, 'Decoded:', decoded);
      return res.sendStatus(403);
    }
    
    req.user = decoded;
    next();
  });
};

// Helper to send push notifications
async function sendPushNotification(userId: number, title: string, body: string, data?: any) {
  try {
    const subscriptions = db.prepare('SELECT subscription FROM push_subscriptions WHERE user_id = ?').all(userId) as any[];
    
    const payload = JSON.stringify({
      notification: {
        title,
        body,
        icon: '/logo192.png',
        badge: '/logo192.png',
        data: data || {}
      }
    });

    for (const sub of subscriptions) {
      try {
        const subscription = JSON.parse(sub.subscription);
        await webpush.sendNotification(subscription, payload);
      } catch (error: any) {
        if (error.statusCode === 410 || error.statusCode === 404) {
          // Subscription expired or no longer valid
          db.prepare('DELETE FROM push_subscriptions WHERE subscription = ?').run(sub.subscription);
        } else {
          console.error('Push notification error:', error);
        }
      }
    }
  } catch (error) {
    console.error('Failed to send push notification:', error);
  }
}

// Helper to create notifications
function createNotification(userId: number, title: string, message: string, type: 'alert' | 'success' | 'info' | 'warning', transactionId?: number) {
  try {
    const stmt = db.prepare('INSERT INTO notifications (user_id, title, message, date, type, transaction_id) VALUES (?, ?, ?, ?, ?, ?)');
    stmt.run(userId, title, message, new Date().toISOString(), type, transactionId || null);
    
    // Also send push notification
    sendPushNotification(userId, title, message, { type, transactionId });
  } catch (error) {
    console.error('Failed to create notification:', error);
  }
}

async function startServer() {
  const app = express();
  app.set('trust proxy', 1);
  
  // Helmet for basic security headers
  app.use(helmet({
    contentSecurityPolicy: false, // Disabled for dev/iframe compatibility
    crossOriginEmbedderPolicy: false,
    crossOriginOpenerPolicy: false,
    crossOriginResourcePolicy: false,
    frameguard: false,
  }));
  
  // Rate limiting for sensitive routes
  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 10, // Limit each IP to 10 requests per window
    message: { success: false, error: 'Too many authentication attempts, please try again later.' },
    standardHeaders: true,
    legacyHeaders: false,
    validate: { xForwardedForHeader: false },
  });

  const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 500,
    message: { success: false, error: 'Too many requests, please try again later.' },
    standardHeaders: true,
    legacyHeaders: false,
    validate: { xForwardedForHeader: false },
  });

  const paymentLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // Limit each IP to 5 payment attempts per 15 mins
    message: { success: false, error: 'Too many payment attempts. Please wait.' },
    standardHeaders: true,
    legacyHeaders: false,
    validate: { xForwardedForHeader: false },
  });

  // Helper for input validation
  const validateEmail = (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const validatePhone = (phone: string) => /^\d{11}$/.test(phone.replace(/\D/g, ''));

  app.use('/api/', apiLimiter);
  app.use('/api/auth/', authLimiter);

  app.use(cookieParser());
  app.use(express.json({ limit: '10mb' }));

  // CSRF protection
  const csrfProtection = csrf({ 
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict'
    } 
  });

  // Termii SMS Helper
  const sendSMS = async (to: string, message: string) => {
    const apiKey = process.env.TERMII_API_KEY;
    const senderId = process.env.TERMII_SENDER_ID || 'KosiBills';

    if (!apiKey) {
      console.warn('Termii API Key not configured. SMS not sent.');
      return { success: false, error: 'API Key missing' };
    }

    try {
      const response = await fetch('https://api.ng.termii.com/api/sms/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to,
          from: senderId,
          sms: message,
          type: 'plain',
          channel: 'generic',
          api_key: apiKey
        })
      });

      const data = await response.json();
      return { success: true, data };
    } catch (error) {
      console.error('Termii SMS Error:', error);
      return { success: false, error };
    }
  };

  // Email Helper
  const sendEmail = async (to: string, subject: string, text: string, html?: string) => {
    const host = process.env.SMTP_HOST;
    const port = parseInt(process.env.SMTP_PORT || '587');
    const user = process.env.SMTP_USER;
    const pass = process.env.SMTP_PASS;
    const from = process.env.SMTP_FROM || 'Kosi Bills <noreply@kosibills.com>';

    if (!host || !user || !pass) {
      console.warn('SMTP configuration missing. Email not sent.');
      return { success: false, error: 'SMTP config missing' };
    }

    try {
      const transporter = nodemailer.createTransport({
        host,
        port,
        secure: port === 465,
        auth: { user, pass }
      });

      await transporter.sendMail({
        from,
        to,
        subject,
        text,
        html: html || text
      });

      return { success: true };
    } catch (error) {
      console.error('Email Error:', error);
      return { success: false, error };
    }
  };

  const sendTransactionEmail = async (userId: number, title: string, message: string) => {
    try {
      const user = db.prepare('SELECT email, name FROM users WHERE id = ?').get(userId) as any;
      if (user && user.email) {
        await sendEmail(
          user.email,
          `Transaction Notification: ${title}`,
          `Hello ${user.name || 'User'},\n\n${message}\n\nBest regards,\nKosi Bills Team`
        );
      }
    } catch (error) {
      console.error('Failed to send transaction email:', error);
    }
  };

  // API Routes
  const otpStore = new Map<string, string>(); // In-memory store for OTPs
  const twoFactorStore = new Map<string, { code: string, userId: number, email: string }>(); // Store for 2FA codes

  app.post('/api/auth/send-otp', async (req, res) => {
    const { phone } = req.body;
    if (!phone) return res.status(400).json({ error: 'Phone number required' });

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    otpStore.set(phone, otp);
    setTimeout(() => otpStore.delete(phone), 600000); // Expire in 10 mins
    
    const message = `Your Kosi Bills OTP is ${otp}. Valid for 10 minutes.`;

    const result = await sendSMS(phone, message);
    if (result.success) {
      res.json({ success: true, message: 'OTP sent successfully' });
    } else {
      res.status(500).json({ success: false, error: 'Failed to send OTP' });
    }
  });

  app.post('/api/auth/verify-otp', (req, res) => {
    const { phone, otp } = req.body;
    if (otpStore.get(phone) === otp) {
      otpStore.delete(phone);
      res.json({ success: true, message: 'OTP verified successfully' });
    } else {
      res.status(400).json({ success: false, error: 'Invalid or expired OTP' });
    }
  });

  app.post('/api/auth/register', authLimiter, (req, res) => {
    const result = registerSchema.safeParse(req.body);
    if (!result.success) return res.status(400).json({ error: result.error.issues[0].message });
    const { name, email, phone, password } = result.data;
    try {
      const safeName = name || 'USR';
      const referralCode = `KOSI-${safeName.substring(0, 3).toUpperCase()}${Math.floor(1000 + Math.random() * 9000)}`;
      const verificationToken = crypto.randomBytes(32).toString('hex');
      const stmt = db.prepare('INSERT INTO users (name, email, phone, password, balance, tier, pin, referral_code, last_login_at, verification_token) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
      // Start with 0 balance
      const info = stmt.run(name, email, phone, hashPassword(password), 0, 'Basic', '1234', referralCode, new Date().toISOString(), verificationToken);
      
      // Send Verification Email
      const verificationUrl = `${process.env.APP_URL}/api/auth/verify-email?token=${verificationToken}`;
      sendEmail(
        email,
        'Verify Your Email - Kosi Bills',
        `
        <div style="font-family: sans-serif; max-width: 600px; margin: auto;">
          <h2>Welcome to Kosi Bills!</h2>
          <p>Hello ${name},</p>
          <p>Thank you for signing up. Please verify your email address by clicking the button below:</p>
          <a href="${verificationUrl}" style="display: inline-block; padding: 12px 24px; background-color: #10b981; color: white; text-decoration: none; border-radius: 8px; font-weight: bold;">Verify Email</a>
          <p>If the button doesn't work, copy and paste this link into your browser:</p>
          <p>${verificationUrl}</p>
          <p>Best regards,<br>Kosi Bills Team</p>
        </div>
        `
      );

      // Add initial transaction
      const txStmt = db.prepare('INSERT INTO transactions (user_id, type, description, amount, date, status) VALUES (?, ?, ?, ?, ?, ?)');
      txStmt.run(info.lastInsertRowid, 'Wallet Fund', 'Account Created', 0, new Date().toISOString(), 'success');

      let isAdmin = false;
      if (email === 'kelvinnnatu2@gmail.com') {
        db.prepare('UPDATE users SET is_admin = 1 WHERE id = ?').run(info.lastInsertRowid);
        isAdmin = true;
      }

      const sessionToken = crypto.randomBytes(32).toString('hex');
      const token = jwt.sign({ id: info.lastInsertRowid, email, session_token: sessionToken }, JWT_SECRET, { expiresIn: '1h' });
      
      db.prepare('UPDATE users SET session_token = ? WHERE id = ?').run(sessionToken, info.lastInsertRowid);
      
      // Send Welcome Email
      sendEmail(
        email,
        'Welcome to Kosi Bills!',
        `Hello ${name},\n\nWelcome to Kosi Bills! We're excited to have you on board. You can now fund your wallet, pay bills, and manage your finances with ease.\n\nYour referral code is: ${referralCode}\n\nBest regards,\nKosi Bills Team`
      );

      res.cookie('token', token, {
        httpOnly: true,
        secure: true,
        sameSite: 'none',
        maxAge: 3600000 // 1 hour
      });

      res.json({ 
        success: true, 
        user: { 
          id: info.lastInsertRowid, 
          name, 
          email, 
          phone,
          balance: 0, 
          tier: 'Basic', 
          isLiveMode: false, 
          isBiometricEnabled: false,
          pin: '1234',
          accountStatus: 'active',
          kycLevel: 1,
          currency: 'NGN',
          isAgent: false,
          isAdmin,
          referralCode,
          hideBalance: false
        } 
      });
    } catch (error: any) {
      if (error.code === 'SQLITE_CONSTRAINT_UNIQUE') {
        res.status(400).json({ error: 'Email already exists' });
      } else {
        res.status(500).json({ error: 'Database error' });
      }
    }
  });

  app.get('/api/auth/verify-email', (req, res) => {
    const { token } = req.query;
    if (!token) return res.status(400).json({ error: 'Token required' });

    try {
      const user = db.prepare('SELECT id FROM users WHERE verification_token = ?').get(token) as any;
      if (!user) return res.status(400).json({ error: 'Invalid or expired token' });

      db.prepare('UPDATE users SET is_email_verified = 1, verification_token = NULL WHERE id = ?').run(user.id);
      
      res.send(`
        <div style="font-family: sans-serif; text-align: center; padding: 50px;">
          <h1 style="color: #10b981;">Email Verified!</h1>
          <p>Your email has been successfully verified. You can now log in to your account.</p>
          <a href="/" style="display: inline-block; padding: 12px 24px; background-color: #10b981; color: white; text-decoration: none; border-radius: 8px; font-weight: bold;">Go to App</a>
        </div>
      `);
    } catch (error) {
      res.status(500).json({ error: 'Verification failed' });
    }
  });

  app.post('/api/auth/resend-verification', (req, res) => {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email required' });

    try {
      const user = db.prepare('SELECT id, name, is_email_verified FROM users WHERE email = ?').get(email) as any;
      if (!user) return res.status(404).json({ error: 'User not found' });
      if (user.is_email_verified) return res.status(400).json({ error: 'Email already verified' });

      const verificationToken = crypto.randomBytes(32).toString('hex');
      db.prepare('UPDATE users SET verification_token = ? WHERE id = ?').run(verificationToken, user.id);

      const verificationUrl = `${process.env.APP_URL}/api/auth/verify-email?token=${verificationToken}`;
      sendEmail(
        email,
        'Verify Your Email - Kosi Bills',
        `
        <div style="font-family: sans-serif; max-width: 600px; margin: auto;">
          <h2>Email Verification</h2>
          <p>Hello ${user.name || 'User'},</p>
          <p>Please verify your email address by clicking the button below:</p>
          <a href="${verificationUrl}" style="display: inline-block; padding: 12px 24px; background-color: #10b981; color: white; text-decoration: none; border-radius: 8px; font-weight: bold;">Verify Email</a>
          <p>If you didn't create an account, you can safely ignore this email.</p>
          <p>Best regards,<br>Kosi Bills Team</p>
        </div>
        `
      );

      res.json({ success: true, message: 'Verification email sent' });
    } catch (error) {
      res.status(500).json({ error: 'Failed to send verification email' });
    }
  });

  app.post('/api/auth/google', (req, res) => {
    const { name, email, profilePhoto } = req.body;
    try {
      let user = db.prepare('SELECT * FROM users WHERE email = ?').get(email) as any;
      
      if (!user) {
        const safeName = name || 'USR';
        const safeProfilePhoto = profilePhoto || null;
        const referralCode = `KOSI-${safeName.substring(0, 3).toUpperCase()}${Math.floor(1000 + Math.random() * 9000)}`;
        const stmt = db.prepare('INSERT INTO users (name, email, phone, password, balance, tier, pin, referral_code, profile_photo, last_login_at, is_email_verified) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        const randomPassword = crypto.randomBytes(16).toString('hex');
        const info = stmt.run(safeName, email, '', hashPassword(randomPassword), 0, 'Basic', '1234', referralCode, safeProfilePhoto, new Date().toISOString(), 1);
        
        const txStmt = db.prepare('INSERT INTO transactions (user_id, type, description, amount, date, status) VALUES (?, ?, ?, ?, ?, ?)');
        txStmt.run(info.lastInsertRowid, 'Wallet Fund', 'Account Created', 0, new Date().toISOString(), 'success');
        
        user = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid) as any;
      } else {
        db.prepare('UPDATE users SET last_login_at = ? WHERE id = ?').run(new Date().toISOString(), user.id);
      }
      
      if (email === 'kelvinnnatu2@gmail.com' && !user.is_admin) {
        db.prepare('UPDATE users SET is_admin = 1 WHERE id = ?').run(user.id);
        user.is_admin = 1;
      }
      
      const { password: _, ...userWithoutPassword } = user;
      
      const mappedUser = {
        ...userWithoutPassword,
        isLiveMode: !!userWithoutPassword.is_live_mode,
        isBiometricEnabled: !!userWithoutPassword.is_biometric_enabled,
        isAgent: !!userWithoutPassword.is_agent,
        isAdmin: !!userWithoutPassword.is_admin,
        isCustomerCare: !!userWithoutPassword.is_customer_care,
        hideBalance: !!userWithoutPassword.hide_balance,
        accountStatus: userWithoutPassword.account_status,
        kycLevel: userWithoutPassword.kyc_level,
        profilePhoto: userWithoutPassword.profile_photo,
        referralCode: userWithoutPassword.referral_code,
        isEmailVerified: !!userWithoutPassword.is_email_verified,
        emailReceiptsEnabled: !!userWithoutPassword.email_receipts_enabled
      };
      
      const sessionToken = crypto.randomBytes(32).toString('hex');
      const token = jwt.sign({ id: mappedUser.id, email: mappedUser.email, session_token: sessionToken }, JWT_SECRET, { expiresIn: '1h' });
      
      db.prepare('UPDATE users SET session_token = ? WHERE id = ?').run(sessionToken, mappedUser.id);
      
      res.cookie('token', token, {
        httpOnly: true,
        secure: true,
        sameSite: 'none',
        maxAge: 3600000 // 1 hour
      });
      
      createNotification(mappedUser.id, 'New Login', 'A new sign-in was detected on your account via Google.', 'info');
      
      res.json({ success: true, user: mappedUser });
    } catch (error: any) {
      console.error('Google Auth Error:', error);
      res.status(500).json({ error: error.message || 'Database error' });
    }
  });

  app.post('/api/auth/login', authLimiter, (req, res) => {
    const result = loginSchema.safeParse(req.body);
    if (!result.success) return res.status(400).json({ error: result.error.issues[0].message });
    const { email, password } = result.data;
    const stmt = db.prepare('SELECT * FROM users WHERE email = ?');
    const user = stmt.get(email) as any;
    
    if (user && verifyPassword(password, user.password)) {
      if (email === 'kelvinnnatu2@gmail.com' && !user.is_admin) {
        db.prepare('UPDATE users SET is_admin = 1, last_login_at = ? WHERE id = ?').run(new Date().toISOString(), user.id);
        user.is_admin = 1;
      } else {
        db.prepare('UPDATE users SET last_login_at = ? WHERE id = ?').run(new Date().toISOString(), user.id);
      }
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      
      // Convert SQLite 0/1 to boolean and map keys
      const mappedUser = {
        ...userWithoutPassword,
        isLiveMode: !!userWithoutPassword.is_live_mode,
        isBiometricEnabled: !!userWithoutPassword.is_biometric_enabled,
        isAgent: !!userWithoutPassword.is_agent,
        isAdmin: !!userWithoutPassword.is_admin,
        isCustomerCare: !!userWithoutPassword.is_customer_care,
        hideBalance: !!userWithoutPassword.hide_balance,
        accountStatus: userWithoutPassword.account_status,
        kycLevel: userWithoutPassword.kyc_level,
        profilePhoto: userWithoutPassword.profile_photo,
        referralCode: userWithoutPassword.referral_code,
        twoFactorEnabled: !!userWithoutPassword.two_factor_enabled,
        isEmailVerified: !!userWithoutPassword.is_email_verified,
        emailReceiptsEnabled: !!userWithoutPassword.email_receipts_enabled
      };

      // Check for 2FA
      if (mappedUser.twoFactorEnabled) {
        const twoFactorCode = Math.floor(100000 + Math.random() * 900000).toString();
        twoFactorStore.set(mappedUser.email, { code: twoFactorCode, userId: mappedUser.id, email: mappedUser.email });
        setTimeout(() => twoFactorStore.delete(mappedUser.email), 300000); // 5 mins expiry

        sendEmail(
          mappedUser.email,
          'Your 2FA Verification Code',
          `Hello ${mappedUser.name || 'User'},\n\nYour Kosi Bills login verification code is: ${twoFactorCode}\n\nThis code will expire in 5 minutes.\n\nBest regards,\nKosi Bills Team`
        );

        return res.json({ 
          success: true, 
          requires2FA: true, 
          email: mappedUser.email,
          message: 'Verification code sent to your email' 
        });
      }
      
      const sessionToken = crypto.randomBytes(32).toString('hex');
      const token = jwt.sign({ id: mappedUser.id, email: mappedUser.email, session_token: sessionToken }, JWT_SECRET, { expiresIn: '1h' });
      
      db.prepare('UPDATE users SET session_token = ? WHERE id = ?').run(sessionToken, mappedUser.id);
      
      res.cookie('token', token, {
        httpOnly: true,
        secure: true,
        sameSite: 'none',
        maxAge: 3600000 // 1 hour
      });
      
      // Send Login Notification Email
      sendEmail(
        mappedUser.email,
        'New Login Detected',
        `Hello ${mappedUser.name || 'User'},\n\nA new login was detected on your Kosi Bills account at ${new Date().toLocaleString()}.\n\nIf this was not you, please secure your account immediately.\n\nBest regards,\nKosi Bills Team`
      );
      
      // Create login notification
      createNotification(mappedUser.id, 'New Login', 'A new sign-in was detected on your account.', 'info');
      
      res.json({ success: true, user: mappedUser });
    } else {
      res.status(401).json({ error: 'Invalid email or password' });
    }
  });

  app.post('/api/auth/forgot-password', (req, res) => {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email required' });

    try {
      const user = db.prepare('SELECT id, name FROM users WHERE email = ?').get(email) as any;
      if (!user) {
        return res.json({ success: true, message: 'If an account exists with this email, a reset link has been sent.' });
      }

      const resetToken = crypto.randomBytes(32).toString('hex');
      const expiry = new Date(Date.now() + 3600000).toISOString(); // 1 hour

      db.prepare('UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE id = ?').run(resetToken, expiry, user.id);

      const resetUrl = `${process.env.APP_URL}/reset-password?token=${resetToken}`;
      sendEmail(
        email,
        'Reset Your Password - Kosi Bills',
        `
        <div style="font-family: sans-serif; max-width: 600px; margin: auto;">
          <h2>Password Reset Request</h2>
          <p>Hello ${user.name || 'User'},</p>
          <p>You requested to reset your password. Click the button below to set a new password:</p>
          <a href="${resetUrl}" style="display: inline-block; padding: 12px 24px; background-color: #10b981; color: white; text-decoration: none; border-radius: 8px; font-weight: bold;">Reset Password</a>
          <p>This link will expire in 1 hour.</p>
          <p>If you didn't request this, you can safely ignore this email.</p>
          <p>Best regards,<br>Kosi Bills Team</p>
        </div>
        `
      );

      res.json({ success: true, message: 'Reset link sent to your email' });
    } catch (error) {
      res.status(500).json({ error: 'Failed to process request' });
    }
  });

  app.post('/api/auth/reset-password', (req, res) => {
    const { token, newPassword } = req.body;
    if (!token || !newPassword) return res.status(400).json({ error: 'Token and new password required' });

    try {
      const user = db.prepare('SELECT id, name, email FROM users WHERE reset_token = ? AND reset_token_expiry > ?').get(token, new Date().toISOString()) as any;
      if (!user) return res.status(400).json({ error: 'Invalid or expired reset token' });

      db.prepare('UPDATE users SET password = ?, reset_token = NULL, reset_token_expiry = NULL WHERE id = ?').run(hashPassword(newPassword), user.id);
      
      createNotification(user.id, 'Password Changed', 'Your account password has been successfully reset.', 'warning');
      
      sendEmail(
        user.email,
        'Password Reset Successful',
        `Hello ${user.name || 'User'},\n\nYour Kosi Bills account password has been successfully reset. If you did not perform this action, please contact support immediately.\n\nBest regards,\nKosi Bills Team`
      );

      res.json({ success: true, message: 'Password updated successfully' });
    } catch (error) {
      res.status(500).json({ error: 'Failed to reset password' });
    }
  });

  app.post('/api/auth/verify-2fa', (req, res) => {
    const { email, code } = req.body;
    const storedData = twoFactorStore.get(email);

    if (!storedData || storedData.code !== code) {
      return res.status(400).json({ error: 'Invalid or expired verification code' });
    }

    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(storedData.userId) as any;
    twoFactorStore.delete(email);

    const sessionToken = crypto.randomBytes(32).toString('hex');
    const token = jwt.sign({ id: user.id, email: user.email, session_token: sessionToken }, JWT_SECRET, { expiresIn: '1h' });
    
    db.prepare('UPDATE users SET session_token = ? WHERE id = ?').run(sessionToken, user.id);
    
    res.cookie('token', token, {
      httpOnly: true,
      secure: true,
      sameSite: 'none',
      maxAge: 3600000 // 1 hour
    });

    res.json({ 
      success: true, 
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        balance: user.balance,
        tier: user.tier,
        isLiveMode: !!user.is_live_mode,
        isAgent: !!user.is_agent,
        isAdmin: !!user.is_admin,
        isCustomerCare: !!user.is_customer_care,
        referralCode: user.referral_code
      }
    });
  });

  app.post('/api/auth/2fa/toggle', authenticateToken, (req: any, res) => {
    const { enabled } = req.body;
    const userId = req.user.id;

    try {
      db.prepare('UPDATE users SET two_factor_enabled = ? WHERE id = ?').run(enabled ? 1 : 0, userId);
      res.json({ success: true, message: `2FA ${enabled ? 'enabled' : 'disabled'} successfully` });
    } catch (error) {
      res.status(500).json({ error: 'Failed to update 2FA status' });
    }
  });

  // Get User Details
  app.get('/api/user/:id', (req, res) => {
    const { id } = req.params;
    try {
      const stmt = db.prepare('SELECT id, name, email, phone, balance, tier, is_live_mode as isLiveMode, is_biometric_enabled as isBiometricEnabled, pin, profile_photo as profilePhoto, account_status as accountStatus, kyc_level as kycLevel, currency, is_agent as isAgent, is_admin as isAdmin, is_customer_care as isCustomerCare, referral_code as referralCode, hide_balance as hideBalance, daily_transfer_limit as dailyTransferLimit, daily_withdrawal_limit as dailyWithdrawalLimit, total_referred as totalReferred, bvn, last_login_at as lastLoginAt, two_factor_enabled as twoFactorEnabled FROM users WHERE id = ?');
      const user = stmt.get(id) as any;
      
      if (user) {
        user.isLiveMode = !!user.isLiveMode;
        user.isBiometricEnabled = !!user.isBiometricEnabled;
        user.isAgent = !!user.isAgent;
        user.isAdmin = !!user.isAdmin;
        user.isCustomerCare = !!user.isCustomerCare;
        user.hideBalance = !!user.hideBalance;
        res.json({ success: true, user });
      } else {
        res.status(404).json({ error: 'User not found' });
      }
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch user' });
    }
  });

  // Verify PIN
  app.post('/api/user/verify-pin', (req, res) => {
    const { userId, pin } = req.body;
    const user = db.prepare('SELECT pin FROM users WHERE id = ?').get(userId) as any;
    if (user && user.pin === pin) {
      res.json({ success: true });
    } else {
      res.status(401).json({ error: 'Invalid transaction PIN' });
    }
  });

  // Update User Profile/Settings
  app.post('/api/user/update', (req, res) => {
    const { userId, tier, isLiveMode, isBiometricEnabled, hideBalance, pin, name, password, phone, profilePhoto, accountStatus, kycLevel, currency } = req.body;
    try {
      const stmt = db.prepare(`
        UPDATE users 
        SET tier = COALESCE(?, tier), 
            is_live_mode = COALESCE(?, is_live_mode), 
            is_biometric_enabled = COALESCE(?, is_biometric_enabled),
            hide_balance = COALESCE(?, hide_balance),
            pin = COALESCE(?, pin),
            name = COALESCE(?, name),
            password = COALESCE(?, password),
            phone = COALESCE(?, phone),
            profile_photo = COALESCE(?, profile_photo),
            account_status = COALESCE(?, account_status),
            kyc_level = COALESCE(?, kyc_level),
            currency = COALESCE(?, currency)
        WHERE id = ?
      `);
      
      const hashedPass = password ? hashPassword(password) : null;
      stmt.run(
        tier, 
        isLiveMode !== undefined ? (isLiveMode ? 1 : 0) : null, 
        isBiometricEnabled !== undefined ? (isBiometricEnabled ? 1 : 0) : null, 
        hideBalance !== undefined ? (hideBalance ? 1 : 0) : null,
        pin, 
        name, 
        hashedPass, 
        phone, 
        profilePhoto, 
        accountStatus, 
        kycLevel, 
        currency, 
        userId
      );

      if (password) {
        createNotification(userId, 'Password Updated', 'Your account password was updated successfully.', 'warning');
      }
      if (pin) {
        createNotification(userId, 'PIN Updated', 'Your transaction PIN was updated successfully.', 'warning');
      }
      
      const updatedUser = db.prepare('SELECT id, name, email, phone, balance, tier, is_live_mode as isLiveMode, is_biometric_enabled as isBiometricEnabled, pin, profile_photo as profilePhoto, account_status as accountStatus, kyc_level as kycLevel, currency, is_agent as isAgent, is_admin as isAdmin, is_customer_care as isCustomerCare, referral_code as referralCode, hide_balance as hideBalance, daily_transfer_limit as dailyTransferLimit, daily_withdrawal_limit as dailyWithdrawalLimit, total_referred as totalReferred, bvn, last_login_at as lastLoginAt, two_factor_enabled as twoFactorEnabled FROM users WHERE id = ?').get(userId) as any;
      
      if (updatedUser) {
        updatedUser.isLiveMode = !!updatedUser.isLiveMode;
        updatedUser.isBiometricEnabled = !!updatedUser.isBiometricEnabled;
        updatedUser.isAgent = !!updatedUser.isAgent;
        updatedUser.isAdmin = !!updatedUser.isAdmin;
        updatedUser.isCustomerCare = !!updatedUser.isCustomerCare;
        updatedUser.hideBalance = !!updatedUser.hideBalance;

        // Send email if password was changed
        if (password) {
          sendEmail(
            updatedUser.email,
            'Security Alert: Password Changed',
            `Hello ${updatedUser.name || 'User'},\n\nYour Kosi Bills account password has been successfully changed. If you did not perform this action, please contact support immediately.\n\nBest regards,\nKosi Bills Team`
          );
        }

        res.json({ success: true, user: updatedUser });
      } else {
        res.status(404).json({ error: 'User not found after update' });
      }
    } catch (error) {
      res.status(500).json({ error: 'Update failed' });
    }
  });

  app.post('/api/user/apply-agent', (req, res) => {
    const { userId } = req.body;
    try {
      // In a real app, this would go to an admin approval queue.
      // For this demo, we auto-approve them.
      db.prepare('UPDATE users SET is_agent = 1 WHERE id = ?').run(userId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to apply for agent' });
    }
  });

  app.post('/api/user/toggle-email-receipts', authenticateToken, (req: any, res) => {
    const { enabled } = req.body;
    try {
      db.prepare('UPDATE users SET email_receipts_enabled = ? WHERE id = ?').run(enabled ? 1 : 0, req.user.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to update preference' });
    }
  });

  // Sub-Wallets Endpoints
  app.get('/api/sub-wallets/:userId', (req, res) => {
    const { userId } = req.params;
    try {
      // Get owned sub-wallets
      const ownedStmt = db.prepare('SELECT * FROM sub_wallets WHERE owner_id = ?');
      const owned = ownedStmt.all(userId);

      // Get shared sub-wallets
      const sharedStmt = db.prepare(`
        SELECT sw.*, swm.allowed_categories 
        FROM sub_wallets sw 
        JOIN sub_wallet_members swm ON sw.id = swm.sub_wallet_id 
        WHERE swm.user_id = ?
      `);
      const shared = sharedStmt.all(userId);

      // Get members for owned sub-wallets
      const membersStmt = db.prepare(`
        SELECT swm.*, u.name, u.email 
        FROM sub_wallet_members swm 
        JOIN users u ON swm.user_id = u.id 
        WHERE swm.sub_wallet_id = ?
      `);
      
      const ownedWithMembers = owned.map((wallet: any) => ({
        ...wallet,
        members: membersStmt.all(wallet.id)
      }));

      res.json({ success: true, owned: ownedWithMembers, shared });
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch sub-wallets' });
    }
  });

  app.post('/api/sub-wallets/create', (req, res) => {
    const { ownerId, name } = req.body;
    try {
      const stmt = db.prepare('INSERT INTO sub_wallets (owner_id, name, balance) VALUES (?, ?, 0)');
      const info = stmt.run(ownerId, name);
      res.json({ success: true, subWalletId: info.lastInsertRowid });
    } catch (error) {
      res.status(500).json({ error: 'Failed to create sub-wallet' });
    }
  });

  app.post('/api/sub-wallets/fund', (req, res) => {
    const { userId, subWalletId, amount } = req.body;
    try {
      const updateMain = db.prepare('UPDATE users SET balance = balance - ? WHERE id = ?');
      const updateSub = db.prepare('UPDATE sub_wallets SET balance = balance + ? WHERE id = ?');
      const insertTx = db.prepare('INSERT INTO transactions (user_id, type, description, amount, date, status, category, sub_wallet_id, balance_after) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');

      const transaction = db.transaction(() => {
        const user = db.prepare('SELECT balance FROM users WHERE id = ?').get(userId) as any;
        if (!user || user.balance < amount) {
          throw new Error('Insufficient balance');
        }

        updateMain.run(amount, userId);
        updateSub.run(amount, subWalletId);
        const newBalance = user.balance - amount;
        insertTx.run(userId, 'Sub-Wallet Funding', `Funded sub-wallet #${subWalletId}`, -amount, new Date().toISOString(), 'success', 'Transfer', subWalletId, newBalance);
      });

      transaction();
      
      // Create notification
      createNotification(userId, 'Sub-Wallet Funded', `You successfully funded sub-wallet #${subWalletId} with ₦${amount.toLocaleString()}`, 'success');
      
      res.json({ success: true });
    } catch (error: any) {
      if (error.message === 'Insufficient balance') {
        res.status(400).json({ error: 'Insufficient balance' });
      } else {
        res.status(500).json({ error: 'Failed to fund sub-wallet' });
      }
    }
  });

  app.post('/api/sub-wallets/add-member', (req, res) => {
    const { subWalletId, email, allowedCategories } = req.body;
    try {
      const user = db.prepare('SELECT id FROM users WHERE email = ?').get(email) as any;
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      const checkMember = db.prepare('SELECT id FROM sub_wallet_members WHERE sub_wallet_id = ? AND user_id = ?').get(subWalletId, user.id);
      if (checkMember) {
        return res.status(400).json({ error: 'User is already a member' });
      }

      const stmt = db.prepare('INSERT INTO sub_wallet_members (sub_wallet_id, user_id, allowed_categories) VALUES (?, ?, ?)');
      stmt.run(subWalletId, user.id, allowedCategories);
      
      // Create notification for the added member
      createNotification(user.id, 'Added to Sub-Wallet', `You have been added as a member to sub-wallet #${subWalletId}`, 'info');
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to add member' });
    }
  });

  // Payment Endpoint
  app.post('/api/payments/pay', (req, res) => {
    const { userId, pin, type, description, amount, metadata } = req.body;
    
    try {
      const updateBalance = db.prepare('UPDATE users SET balance = balance - ? WHERE id = ?');
      const insertTx = db.prepare('INSERT INTO transactions (user_id, type, description, amount, date, status, balance_after, metadata) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');

      let txId: number | bigint = 0;
      let finalAmount = amount;
      
      const userStmt = db.prepare('SELECT balance, is_agent, pin FROM users WHERE id = ?');
      const user = userStmt.get(userId) as any;

      if (!user) throw new Error('User not found');
      
      if (user.pin && (!pin || user.pin !== pin)) {
        return res.status(400).json({ success: false, error: 'Invalid transaction PIN' });
      }
      
      if (user.is_agent) {
        finalAmount = amount * 0.98; // 2% discount
      }

      if (user.balance < finalAmount) {
        insertTx.run(userId, type, description, -finalAmount, new Date().toISOString(), 'failed', user.balance, metadata ? JSON.stringify(metadata) : null);
        return res.status(400).json({ success: false, error: 'Insufficient balance' });
      }

      const transaction = db.transaction(() => {
        updateBalance.run(finalAmount, userId);
        const newBalance = user.balance - finalAmount;
        const result = insertTx.run(userId, type, description, -finalAmount, new Date().toISOString(), 'success', newBalance, metadata ? JSON.stringify(metadata) : null);
        txId = result.lastInsertRowid;
      });

      transaction();

      const updatedUser = db.prepare('SELECT id, name, email, phone, balance, tier, is_live_mode as isLiveMode, is_biometric_enabled as isBiometricEnabled, pin, profile_photo as profilePhoto, account_status as accountStatus, kyc_level as kycLevel, currency, is_agent as isAgent, is_admin as isAdmin, is_customer_care as isCustomerCare, referral_code as referralCode, hide_balance as hideBalance, daily_transfer_limit as dailyTransferLimit, daily_withdrawal_limit as dailyWithdrawalLimit, total_referred as totalReferred, bvn, last_login_at as lastLoginAt, two_factor_enabled as twoFactorEnabled, email_receipts_enabled as emailReceiptsEnabled FROM users WHERE id = ?').get(userId) as any;
      updatedUser.isLiveMode = !!updatedUser.isLiveMode;
      updatedUser.isBiometricEnabled = !!updatedUser.isBiometricEnabled;
      updatedUser.isAgent = !!updatedUser.isAgent;
      updatedUser.isAdmin = !!updatedUser.isAdmin;
      updatedUser.isCustomerCare = !!updatedUser.isCustomerCare;
      updatedUser.hideBalance = !!updatedUser.hideBalance;
      updatedUser.emailReceiptsEnabled = !!updatedUser.emailReceiptsEnabled;

      const notificationMsg = `Your ${type} payment of ₦${finalAmount.toLocaleString()} was successful. Ref: ${txId}`;
      
      // Send email notification to user
      if (updatedUser && updatedUser.email && updatedUser.emailReceiptsEnabled) {
        sendEmail(
          updatedUser.email,
          `Transaction Receipt: ${type}`,
          `Hello ${updatedUser.name || 'User'},\n\nYour ${type} payment of ₦${finalAmount.toLocaleString()} was successful.\n\nTransaction Details:\nType: ${type}\nAmount: ₦${finalAmount.toLocaleString()}\nReference: ${txId}\nDate: ${new Date().toLocaleString()}\n\nThank you for choosing Kosi Bills!`,
          `
          <div style="font-family: sans-serif; max-width: 600px; margin: auto; border: 1px solid #eee; padding: 20px; border-radius: 10px;">
            <h2 style="color: #10b981; text-align: center;">Transaction Receipt</h2>
            <p>Hello <strong>${updatedUser.name || 'User'}</strong>,</p>
            <p>Your <strong>${type}</strong> payment was successful.</p>
            <div style="background-color: #f9fafb; padding: 15px; border-radius: 8px; margin: 20px 0;">
              <table style="width: 100%;">
                <tr><td style="color: #6b7280;">Amount:</td><td style="text-align: right; font-weight: bold;">₦${finalAmount.toLocaleString()}</td></tr>
                <tr><td style="color: #6b7280;">Type:</td><td style="text-align: right;">${type}</td></tr>
                <tr><td style="color: #6b7280;">Reference:</td><td style="text-align: right; font-family: monospace;">${txId}</td></tr>
                <tr><td style="color: #6b7280;">Date:</td><td style="text-align: right;">${new Date().toLocaleString()}</td></tr>
              </table>
            </div>
            <p style="text-align: center; color: #6b7280; font-size: 14px;">Thank you for choosing Kosi Bills!</p>
          </div>
          `
        );
      }

      // Send SMS notification if phone exists
      if (updatedUser.phone) {
        sendSMS(updatedUser.phone, `Kosi Bills: ${notificationMsg}`);
      }

      // Create in-app notification
      createNotification(userId, 'Payment Successful', notificationMsg, 'success', Number(txId));

      res.json({ success: true, user: updatedUser, finalAmount, transactionId: `TXN-${String(txId).padStart(8, '0')}` });
    } catch (error: any) {

      if (error.message === 'Insufficient balance') {
        res.status(400).json({ error: 'Insufficient balance' });
      } else if (error.message === 'User not found') {
        res.status(404).json({ error: 'User not found' });
      } else {
        res.status(500).json({ error: 'Payment failed' });
      }
    }
  });

  // Beneficiaries Endpoints
  app.get('/api/beneficiaries/:userId', (req, res) => {
    const { userId } = req.params;
    try {
      const stmt = db.prepare('SELECT * FROM beneficiaries WHERE user_id = ?');
      const beneficiaries = stmt.all(userId);
      res.json({ success: true, beneficiaries });
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch beneficiaries' });
    }
  });

  app.post('/api/beneficiaries', (req, res) => {
    const { userId, name, phone, serviceType, provider } = req.body;
    try {
      const stmt = db.prepare('INSERT INTO beneficiaries (user_id, name, phone, service_type, provider) VALUES (?, ?, ?, ?, ?)');
      const info = stmt.run(userId, name, phone, serviceType, provider);
      res.json({ success: true, id: info.lastInsertRowid });
    } catch (error) {
      res.status(500).json({ error: 'Failed to add beneficiary' });
    }
  });

  app.delete('/api/beneficiaries/:id', (req, res) => {
    const { id } = req.params;
    try {
      db.prepare('DELETE FROM beneficiaries WHERE id = ?').run(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete beneficiary' });
    }
  });

  // History Endpoint
  app.get('/api/transactions/:userId', (req, res) => {
    const { userId } = req.params;
    try {
      const stmt = db.prepare('SELECT * FROM transactions WHERE user_id = ? ORDER BY id DESC');
      const transactions = stmt.all(userId);
      res.json({ success: true, transactions });
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch history' });
    }
  });

  // Rewards Endpoint
  app.get('/api/rewards', (req, res) => {
    try {
      const stmt = db.prepare('SELECT * FROM rewards');
      const rewards = stmt.all();
      res.json({ success: true, rewards });
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch rewards' });
    }
  });

  app.post('/api/notifications/subscribe', authenticateToken, (req: any, res) => {
    const { subscription } = req.body;
    if (!subscription) return res.status(400).json({ error: 'Subscription required' });

    try {
      const subscriptionStr = JSON.stringify(subscription);
      // Check if subscription already exists
      const existing = db.prepare('SELECT id FROM push_subscriptions WHERE user_id = ? AND subscription = ?').get(req.user.id, subscriptionStr);
      
      if (!existing) {
        db.prepare('INSERT INTO push_subscriptions (user_id, subscription) VALUES (?, ?)').run(req.user.id, subscriptionStr);
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error('Subscription error:', error);
      res.status(500).json({ error: 'Failed to subscribe' });
    }
  });

  // Notifications Endpoints
  app.get('/api/notifications/:userId', (req, res) => {
    const { userId } = req.params;
    console.log('Fetching notifications for user:', userId);
    try {
      if (!userId || userId === 'undefined' || userId === 'null') {
        return res.json({ success: true, notifications: [] });
      }

      const stmt = db.prepare('SELECT id, title, message, date, read, type, transaction_id as transactionId FROM notifications WHERE user_id = ? ORDER BY date DESC LIMIT 50');
      const notifications = stmt.all(userId).map((n: any) => ({
        ...n,
        id: n.id.toString(),
        read: !!n.read,
        transactionId: n.transactionId?.toString()
      }));
      res.json({ success: true, notifications });
    } catch (error) {
      console.error('[Notifications] Error fetching:', error);
      res.status(500).json({ error: 'Failed to fetch notifications' });
    }
  });

  // Bill Services Endpoints
  app.get('/api/bill-services/:service', (req, res) => {
    const { service } = req.params;
    console.log('Fetching bill services for:', service);
    
    // Mock data for now
    const mockData: any = {
      'Data': {
        success: true,
        services: [
          {
            provider_id: 'mtn',
            provider_name: 'MTN',
            packages: [
              { id: 'mtn-1gb', name: '1GB Monthly', price: 1000, category: 'Monthly', validity: '30 days' },
              { id: 'mtn-2gb', name: '2GB Monthly', price: 1800, category: 'Monthly', validity: '30 days' }
            ]
          },
          {
            provider_id: 'airtel',
            provider_name: 'Airtel',
            packages: [
              { id: 'airtel-1gb', name: '1GB Monthly', price: 1000, category: 'Monthly', validity: '30 days' }
            ]
          }
        ]
      },
      'Cable TV': {
        success: true,
        services: []
      },
      'Electricity': {
        success: true,
        services: []
      }
    };

    res.json(mockData[service] || { success: false, error: 'Service not found' });
  });

  app.put('/api/notifications/:userId/read', (req, res) => {
    const { userId } = req.params;
    try {
      const stmt = db.prepare('UPDATE notifications SET read = 1 WHERE user_id = ?');
      stmt.run(userId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to mark notifications as read' });
    }
  });

  app.put('/api/notifications/:userId/read/:id', (req, res) => {
    const { userId, id } = req.params;
    try {
      const stmt = db.prepare('UPDATE notifications SET read = 1 WHERE user_id = ? AND id = ?');
      stmt.run(userId, id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to mark notification as read' });
    }
  });

  const logAdminAction = (adminId: number, action: string, targetId: number | null, details: string) => {
    try {
      db.prepare('INSERT INTO admin_logs (admin_id, action, target_id, details) VALUES (?, ?, ?, ?)').run(
        adminId,
        action,
        targetId,
        details
      );
    } catch (error) {
      console.error('Failed to log admin action:', error);
    }
  };

  // Admin Endpoints
  // Middleware to check admin
  const requireAdmin = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const adminId = req.headers['x-admin-id'];
    if (!adminId) return res.status(401).json({ error: 'Unauthorized' });
    
    const admin = db.prepare('SELECT is_admin FROM users WHERE id = ?').get(adminId) as any;
    if (!admin || !admin.is_admin) return res.status(403).json({ error: 'Forbidden' });
    
    next();
  };

  const requireCustomerCare = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const ccId = req.headers['x-cc-id'] || req.headers['x-admin-id'];
    if (!ccId) return res.status(401).json({ error: 'Unauthorized' });
    
    const cc = db.prepare('SELECT is_customer_care, is_admin FROM users WHERE id = ?').get(ccId) as any;
    if (!cc || (!cc.is_customer_care && !cc.is_admin)) return res.status(403).json({ error: 'Forbidden' });
    
    next();
  };


  app.get('/api/admin/stats', requireAdmin, (req, res) => {
    try {
      const totalUsers = (db.prepare('SELECT COUNT(*) as count FROM users').get() as any).count;
      const totalTransactions = (db.prepare('SELECT COUNT(*) as count FROM transactions').get() as any).count;
      const totalVolume = (db.prepare('SELECT SUM(ABS(amount)) as sum FROM transactions WHERE status = \'success\'').get() as any).sum || 0;
      const activeTickets = (db.prepare('SELECT COUNT(*) as count FROM support_tickets WHERE status = \'open\'').get() as any).count;
      const totalSystemBalance = (db.prepare('SELECT SUM(balance) as sum FROM users').get() as any).sum || 0;
      
      // Get volume by category
      const volumeByCategory = db.prepare(`
        SELECT category, SUM(ABS(amount)) as volume 
        FROM transactions 
        WHERE status = 'success' AND category IS NOT NULL 
        GROUP BY category
        ORDER BY volume DESC
      `).all();

      // Get daily transaction volume for last 14 days
      const dailyVolume = db.prepare(`
        SELECT date(date) as day, SUM(ABS(amount)) as volume 
        FROM transactions 
        WHERE status = 'success' AND date >= date('now', '-14 days')
        GROUP BY day 
        ORDER BY day ASC
      `).all();

      // Get user growth for last 14 days
      const userGrowth = db.prepare(`
        SELECT date(created_at) as day, COUNT(*) as count 
        FROM users 
        WHERE created_at >= date('now', '-14 days')
        GROUP BY day 
        ORDER BY day ASC
      `).all();

      res.json({ 
        success: true, 
        stats: { 
          totalUsers, 
          totalTransactions, 
          totalVolume, 
          activeTickets,
          totalSystemBalance,
          volumeByCategory,
          dailyVolume,
          userGrowth
        } 
      });
    } catch (error) {
      console.error('Stats error:', error);
      res.status(500).json({ error: 'Failed to fetch stats' });
    }
  });

  app.get('/api/admin/users', requireCustomerCare, (req, res) => {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;
    const search = (req.query.search as string) || '';
    const role = (req.query.role as string) || 'all';
    const sortBy = (req.query.sortBy as string) || 'id';
    const sortOrder = (req.query.sortOrder as string) || 'DESC';
    const offset = (page - 1) * limit;

    // Validate sortBy to prevent SQL injection
    const allowedSortFields = ['id', 'name', 'email', 'accountStatus', 'createdAt', 'balance'];
    const dbFieldMap: { [key: string]: string } = {
      id: 'id',
      name: 'name',
      email: 'email',
      accountStatus: 'account_status',
      createdAt: 'created_at',
      balance: 'balance'
    };

    const sortField = allowedSortFields.includes(sortBy) ? dbFieldMap[sortBy] : 'id';
    const order = sortOrder.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

    try {
      let query = 'SELECT id, name, email, phone, balance, tier, is_agent as isAgent, is_admin as isAdmin, is_customer_care as isCustomerCare, account_status as accountStatus, kyc_level as kycLevel, created_at as createdAt, daily_transfer_limit as dailyTransferLimit, daily_withdrawal_limit as dailyWithdrawalLimit, total_referred as totalReferred, bvn, last_login_at as lastLoginAt, two_factor_enabled as twoFactorEnabled FROM users';
      let countQuery = 'SELECT COUNT(*) as count FROM users';
      const params: any[] = [];
      const whereClauses: string[] = [];

      if (search) {
        whereClauses.push('(name LIKE ? OR email LIKE ? OR phone LIKE ?)');
        const searchParam = `%${search}%`;
        params.push(searchParam, searchParam, searchParam);
      }

      if (role === 'agents') {
        whereClauses.push('is_agent = 1');
      } else if (role === 'customers') {
        whereClauses.push('is_agent = 0 AND is_admin = 0');
      } else if (role === 'customer_care') {
        whereClauses.push('is_customer_care = 1');
      }

      if (whereClauses.length > 0) {
        const clause = ' WHERE ' + whereClauses.join(' AND ');
        query += clause;
        countQuery += clause;
      }

      query += ` ORDER BY ${sortField} ${order} LIMIT ? OFFSET ?`;
      const users = db.prepare(query).all(...params, limit, offset).map((u: any) => ({
        ...u,
        isAgent: !!u.isAgent,
        isAdmin: !!u.isAdmin,
        isCustomerCare: !!u.isCustomerCare
      }));

      const total = (db.prepare(countQuery).get(...params) as any).count;

      res.json({ 
        success: true, 
        users,
        pagination: {
          total,
          page,
          limit,
          totalPages: Math.ceil(total / limit)
        }
      });
    } catch (error) {
      console.error('Users error:', error);
      res.status(500).json({ error: 'Failed to fetch users' });
    }
  });

  app.post('/api/admin/send-email', requireAdmin, (req, res) => {
    const { targetEmail, subject, message } = req.body;
    const adminId = Number(req.headers['x-admin-id']);

    if (!targetEmail || !subject || !message) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    try {
      sendEmail(
        targetEmail,
        subject,
        `
        <div style="font-family: sans-serif; max-width: 600px; margin: auto; border: 1px solid #e5e7eb; padding: 20px; border-radius: 12px;">
          <h2 style="color: #10b981;">Message from Kosi Bills Admin</h2>
          <div style="margin: 20px 0; border-top: 1px solid #e5e7eb; padding-top: 20px; line-height: 1.6;">
            ${message.replace(/\n/g, '<br>')}
          </div>
          <p style="font-size: 12px; color: #6b7280; text-align: center; margin-top: 30px;">
            This is an official communication from Kosi Bills.
          </p>
        </div>
        `
      );

      logAdminAction(adminId, 'Send Email', null, `Sent email to ${targetEmail} with subject: ${subject}`);
      res.json({ success: true, message: 'Email sent successfully' });
    } catch (error) {
      console.error('Admin Send Email Error:', error);
      res.status(500).json({ error: 'Failed to send email' });
    }
  });

  app.get('/api/admin/logs', requireAdmin, (req, res) => {
    const limit = 50;
    try {
      const logs = db.prepare(`
        SELECT l.*, u.name as admin_name 
        FROM admin_logs l 
        JOIN users u ON l.admin_id = u.id 
        ORDER BY l.created_at DESC 
        LIMIT ?
      `).all(limit);
      res.json({ success: true, logs });
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch logs' });
    }
  });

  app.post('/api/admin/users/:id/status', requireAdmin, (req, res) => {
    const { id } = req.params;
    const { status } = req.body; // 'active' or 'suspended'
    const adminId = req.headers['x-admin-id'];
    
    try {
      db.prepare('UPDATE users SET account_status = ? WHERE id = ?').run(status, id);
      logAdminAction(parseInt(adminId as string), `user_status_change_${status}`, parseInt(id), `Changed user ${id} status to ${status}`);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to update user status' });
    }
  });

  app.post('/api/admin/users/:id/role', requireAdmin, (req, res) => {
    const { id } = req.params;
    const { role } = req.body;
    const adminId = req.headers['x-admin-id'];
    
    try {
      let isAgent = 0;
      let isCustomerCare = 0;
      let isAdmin = 0;

      if (role === 'agent') isAgent = 1;
      if (role === 'customer_care') isCustomerCare = 1;
      if (role === 'admin') isAdmin = 1;

      db.prepare('UPDATE users SET is_agent = ?, is_customer_care = ?, is_admin = ? WHERE id = ?').run(isAgent, isCustomerCare, isAdmin, id);
      
      // Send email notification to user
      const userInfo = db.prepare('SELECT email, name FROM users WHERE id = ?').get(id) as any;
      if (userInfo && userInfo.email) {
        sendEmail(
          userInfo.email,
          'Account Role Updated',
          `Hello ${userInfo.name || 'User'},\n\nYour Kosi Bills account role has been updated to: ${role.replace('_', ' ').toUpperCase()}.\n\nPlease log in to see your new features and permissions.\n\nBest regards,\nKosi Bills Team`
        );
      }

      logAdminAction(parseInt(adminId as string), `user_role_change_${role}`, parseInt(id), `Changed user ${id} role to ${role}`);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to update user role' });
    }
  });

  app.post('/api/admin/users', requireAdmin, (req, res) => {
    const { name, email, phone, password, isAgent } = req.body;
    try {
      const stmt = db.prepare('INSERT INTO users (name, email, phone, password, is_agent) VALUES (?, ?, ?, ?, ?)');
      const info = stmt.run(name, email, phone, hashPassword(password), isAgent ? 1 : 0);
      res.json({ success: true, userId: info.lastInsertRowid });
    } catch (error: any) {
      if (error.code === 'SQLITE_CONSTRAINT_UNIQUE') {
        res.status(400).json({ error: 'Email already exists' });
      } else {
        res.status(500).json({ error: 'Failed to create user' });
      }
    }
  });

  app.put('/api/admin/users/:id/role', requireAdmin, (req, res) => {
    const { id } = req.params;
    const { isAgent } = req.body;
    try {
      const stmt = db.prepare('UPDATE users SET is_agent = ? WHERE id = ?');
      stmt.run(isAgent ? 1 : 0, id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to update user role' });
    }
  });

  app.post('/api/admin/users/:id/fund', requireAdmin, (req, res) => {
    const { id } = req.params;
    const { amount, type, description } = req.body;
    const adminId = parseInt(req.headers['x-admin-id'] as string);
    
    if (!amount || amount <= 0) return res.status(400).json({ error: 'Invalid amount' });
    if (!['credit', 'debit'].includes(type)) return res.status(400).json({ error: 'Invalid transaction type' });

    try {
      db.transaction(() => {
        const user = db.prepare('SELECT balance FROM users WHERE id = ?').get(id) as any;
        if (!user) throw new Error('User not found');

        const newBalance = type === 'credit' ? user.balance + amount : user.balance - amount;
        
        if (type === 'debit' && newBalance < 0) {
          throw new Error('Insufficient balance for debit');
        }

        db.prepare('UPDATE users SET balance = ? WHERE id = ?').run(newBalance, id);

        const txRef = `MANUAL-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
        db.prepare(`
          INSERT INTO transactions (user_id, type, description, amount, date, status, tx_ref, category, balance_after)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
          id,
          'manual_funding',
          description || `Manual ${type} by Admin`,
          type === 'credit' ? amount : -amount,
          new Date().toISOString(),
          'success',
          txRef,
          'Funding',
          newBalance
        );

        logAdminAction(adminId, `manual_${type}`, parseInt(id), `Manual ${type} of ₦${amount} to user ${id}. Reason: ${description}`);
      })();

      res.json({ success: true, message: `Successfully ${type}ed user wallet` });
    } catch (error: any) {
      console.error('Funding error:', error);
      res.status(400).json({ error: error.message || 'Failed to fund user' });
    }
  });

  app.post('/api/customer-care/users/:id/reset-password', requireCustomerCare, (req, res) => {
    const { id } = req.params;
    try {
      // In a real app, this would generate a token and send an email
      // For this demo, we'll just set a default password 'Password123!'
      const defaultPassword = hashPassword('Password123!');
      const stmt = db.prepare('UPDATE users SET password = ? WHERE id = ?');
      stmt.run(defaultPassword, id);
      createNotification(Number(id), 'Password Reset', 'Your password has been reset by customer care to Password123!', 'warning');
      res.json({ success: true, message: 'Password reset to Password123!' });
    } catch (error) {
      res.status(500).json({ error: 'Failed to reset password' });
    }
  });

  // Admin: Generate VAPID Keys (Helper for setup)
  app.get('/api/admin/generate-vapid', requireAdmin, (req, res) => {
    try {
      const keys = webpush.generateVAPIDKeys();
      res.json({
        success: true,
        publicKey: keys.publicKey,
        privateKey: keys.privateKey,
        message: 'Add these to your environment variables in Settings'
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to generate keys' });
    }
  });

  // Admin: Get all transactions
  app.get('/api/admin/transactions', requireCustomerCare, (req: any, res) => {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;
    const search = (req.query.search as string) || '';
    const status = (req.query.status as string) || 'all';
    const type = (req.query.type as string) || 'all';
    const sortBy = (req.query.sortBy as string) || 'date';
    const sortOrder = (req.query.sortOrder as string) || 'DESC';
    const offset = (page - 1) * limit;

    // Validate sortBy to prevent SQL injection
    const allowedSortFields = ['date', 'amount', 'type', 'status', 'userName'];
    const finalSortBy = allowedSortFields.includes(sortBy) ? sortBy : 'date';
    const finalSortOrder = sortOrder.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

    try {
      let query = `
        SELECT t.*, u.name as userName, u.email as userEmail 
        FROM transactions t 
        JOIN users u ON t.user_id = u.id
        WHERE 1=1
      `;
      let countQuery = `
        SELECT COUNT(*) as count 
        FROM transactions t 
        JOIN users u ON t.user_id = u.id
        WHERE 1=1
      `;
      const params: any[] = [];

      if (search) {
        const searchClause = ' AND (u.name LIKE ? OR u.email LIKE ? OR t.description LIKE ? OR t.tx_ref LIKE ?)';
        query += searchClause;
        countQuery += searchClause;
        const searchParam = `%${search}%`;
        params.push(searchParam, searchParam, searchParam, searchParam);
      }

      if (status !== 'all') {
        query += ' AND t.status = ?';
        countQuery += ' AND t.status = ?';
        params.push(status);
      }

      if (type !== 'all') {
        query += ' AND t.type = ?';
        countQuery += ' AND t.type = ?';
        params.push(type);
      }

      query += ` ORDER BY ${finalSortBy === 'userName' ? 'u.name' : 't.' + finalSortBy} ${finalSortOrder} LIMIT ? OFFSET ?`;
      const transactions = db.prepare(query).all(...params, limit, offset);
      const total = (db.prepare(countQuery).get(...params) as any).count;

      res.json({ 
        success: true, 
        transactions,
        pagination: {
          total,
          page,
          limit,
          totalPages: Math.ceil(total / limit)
        }
      });
    } catch (error) {
      console.error('Transactions error:', error);
      res.status(500).json({ error: 'Failed to fetch transactions' });
    }
  });

  // Admin: Toggle Customer Care role
  app.put('/api/admin/users/:id/customer-care', requireAdmin, (req: any, res) => {
    const { id } = req.params;
    const { isCustomerCare } = req.body;

    try {
      db.prepare('UPDATE users SET is_customer_care = ? WHERE id = ?').run(isCustomerCare ? 1 : 0, id);
      res.json({ success: true, message: 'User role updated' });
    } catch (error) {
      res.status(500).json({ error: 'Failed to update user role' });
    }
  });

  // Support Tickets
  app.post('/api/support/tickets', authenticateToken, (req, res) => {
    const { userId, subject, initialMessage } = req.body;
    try {
      const stmt = db.prepare('INSERT INTO support_tickets (user_id, subject, created_at, updated_at) VALUES (?, ?, ?, ?)');
      const now = new Date().toISOString();
      const info = stmt.run(userId, subject, now, now);
      const ticketId = info.lastInsertRowid;

      const msgStmt = db.prepare('INSERT INTO support_messages (ticket_id, sender_id, sender_type, message, created_at) VALUES (?, ?, ?, ?, ?)');
      msgStmt.run(ticketId, userId, 'user', initialMessage, now);

      // Send confirmation email to user
      const user = db.prepare('SELECT email, name FROM users WHERE id = ?').get(userId) as any;
      if (user && user.email) {
        sendEmail(
          user.email,
          `Support Ticket Created: ${subject}`,
          `Hello ${user.name || 'User'},\n\nYour support ticket "${subject}" has been successfully created. Our team will review it and get back to you shortly.\n\nTicket ID: #${ticketId}\n\nBest regards,\nKosi Bills Support Team`
        );
      }

      res.json({ success: true, ticketId });
    } catch (error) {
      res.status(500).json({ error: 'Failed to create ticket' });
    }
  });

  app.post('/api/support/ai-chat', authenticateToken, async (req, res) => {
    const { message } = req.body;
    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey) {
      return res.status(500).json({ error: 'AI Support not configured' });
    }

    try {
      // Simulate "thinking"
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Local response logic
      const text = generateLocalResponse(message);
      res.json({ success: true, text });
    } catch (error) {
      console.error('AI Chat error:', error);
      res.status(500).json({ error: 'AI failed to respond. Please try again.' });
    }
  });

  function generateLocalResponse(message: string) {
    const msg = message.toLowerCase();
    
    // Context-aware responses
    if (msg.includes('fund') || msg.includes('wallet') || msg.includes('deposit')) {
      return "To fund your wallet securely, navigate to the 'Wallet' tab, select 'Add Funds', and choose your preferred method (Bank Transfer or Card). For instant credit, we recommend Bank Transfer using your unique Kosi Bills virtual account number.";
    }
    
    if (msg.includes('agent') || msg.includes('benefit') || msg.includes('discount')) {
      return "Being a Kosi Bills agent is rewarding! You earn a 2% discount on all transactions. To upgrade, go to 'Settings' > 'Account Type' and apply for Agent status. You'll need to provide basic business verification.";
    }
    
    if (msg.includes('electricity') || msg.includes('bill') || msg.includes('power')) {
      return "Paying electricity bills is easy: select 'Electricity' in the app, choose your provider (e.g., IKEDC, EKEDC), enter your meter number, and confirm the amount. Remember to check your meter type (Prepaid/Postpaid) before payment.";
    }
    
    if (msg.includes('sub-wallet') || msg.includes('family') || msg.includes('business')) {
      return "Sub-wallets are perfect for organizing expenses. You can create one for 'Family' or 'Business' in the 'Wallet' section. You can set spending limits on each sub-wallet to stay within your budget.";
    }
    
    if (msg.includes('rewards') || msg.includes('tier') || msg.includes('gold') || msg.includes('diamond')) {
      return "Your loyalty is rewarded! We have tiers ranging from Basic to Diamond. The more transactions you perform, the higher your tier, unlocking exclusive benefits like lower fees and priority support. Check your current tier in the 'Rewards' dashboard.";
    }

    if (msg.includes('hello') || msg.includes('hi') || msg.includes('hey')) {
      return "Hello! I'm Kosi, your dedicated financial assistant. I'm here to help you navigate Kosi Bills, manage your payments, and optimize your spending. What can I assist you with today?";
    }

    return "I'm Kosi, your financial assistant. I can help you with wallet funding, electricity bills, sub-wallets, rewards, and agent benefits. Could you please be more specific about what you need help with?";
  }

  app.get('/api/support/tickets', requireCustomerCare, (req, res) => {
    try {
      const stmt = db.prepare(`
        SELECT t.*, u.name as userName, u.email as userEmail 
        FROM support_tickets t 
        JOIN users u ON t.user_id = u.id 
        ORDER BY t.updated_at DESC
      `);
      const tickets = stmt.all();
      res.json({ success: true, tickets });
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch tickets' });
    }
  });

  app.get('/api/support/tickets/:id/messages', requireCustomerCare, (req, res) => {
    const { id } = req.params;
    try {
      const stmt = db.prepare('SELECT * FROM support_messages WHERE ticket_id = ? ORDER BY created_at ASC');
      const messages = stmt.all(id);
      res.json({ success: true, messages });
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch messages' });
    }
  });

  app.post('/api/support/tickets/:id/messages', requireCustomerCare, (req, res) => {
    const { id } = req.params;
    const { senderId, message } = req.body;
    try {
      const now = new Date().toISOString();
      const stmt = db.prepare('INSERT INTO support_messages (ticket_id, sender_id, sender_type, message, created_at) VALUES (?, ?, ?, ?, ?)');
      stmt.run(id, senderId, 'agent', message, now);
      
      const updateStmt = db.prepare('UPDATE support_tickets SET updated_at = ? WHERE id = ?');
      updateStmt.run(now, id);
      
      // Send email notification to user
      const ticketInfo = db.prepare(`
        SELECT t.subject, u.email, u.name 
        FROM support_tickets t 
        JOIN users u ON t.user_id = u.id 
        WHERE t.id = ?
      `).get(id) as any;

      if (ticketInfo && ticketInfo.email) {
        sendEmail(
          ticketInfo.email,
          `Support Ticket Update: ${ticketInfo.subject}`,
          `Hello ${ticketInfo.name || 'User'},\n\nYou have a new message on your support ticket: "${ticketInfo.subject}".\n\nMessage: ${message}\n\nPlease log in to your dashboard to view and reply.\n\nBest regards,\nKosi Bills Support Team`
        );
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to send message' });
    }
  });

  // Admin Settings
  app.get('/api/admin/settings', requireAdmin, (req, res) => {
    try {
      const settings = db.prepare('SELECT * FROM system_settings').all();
      const settingsObj = settings.reduce((acc: Record<string, string>, curr: any) => {
        acc[curr.key] = curr.value;
        return acc;
      }, {} as Record<string, string>);
      
      // Default values if not set
      if (!settingsObj.transfer_fee) settingsObj.transfer_fee = '10';
      if (!settingsObj.min_withdrawal) settingsObj.min_withdrawal = '1000';
      if (!settingsObj.maintenance_mode) settingsObj.maintenance_mode = 'false';
      
      res.json({ success: true, settings: settingsObj });
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch settings' });
    }
  });

  // Test Email Route
  app.post('/api/test/email', async (req, res) => {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email is required' });

    const result = await sendEmail(
      email,
      'Kosi Bills: Test Email',
      'This is a test email to verify your SMTP configuration. If you received this, your email notifications are working correctly!',
      '<h1>Kosi Bills Test</h1><p>This is a test email to verify your SMTP configuration. If you received this, your email notifications are working correctly!</p>'
    );

    if (result.success) {
      res.json({ success: true, message: 'Test email sent successfully' });
    } else {
      res.status(500).json({ success: false, error: result.error });
    }
  });

  app.post('/api/admin/settings', requireAdmin, (req, res) => {
    const { settings } = req.body;
    const adminId = parseInt(req.headers['x-admin-id'] as string);
    try {
      db.transaction(() => {
        const stmt = db.prepare('INSERT OR REPLACE INTO system_settings (key, value) VALUES (?, ?)');
        for (const [key, value] of Object.entries(settings)) {
          stmt.run(key, String(value));
        }
        logAdminAction(adminId, 'update_settings', 0, `Updated system settings: ${Object.keys(settings).join(', ')}`);
      })();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to update settings' });
    }
  });

  app.delete('/api/admin/settings/:key', requireAdmin, (req, res) => {
    const { key } = req.params;
    const adminId = parseInt(req.headers['x-admin-id'] as string);
    try {
      db.prepare('DELETE FROM system_settings WHERE key = ?').run(key);
      logAdminAction(adminId, 'delete_setting', 0, `Deleted system setting: ${key}`);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete setting' });
    }
  });

  // Admin Broadcast
  app.post('/api/admin/broadcast', requireAdmin, (req, res) => {
    const { title, message, target } = req.body;
    const adminId = parseInt(req.headers['x-admin-id'] as string);
    
    if (!title || !message) return res.status(400).json({ error: 'Title and message required' });

    try {
      let query = 'INSERT INTO notifications (user_id, title, message, date, type) SELECT id, ?, ?, ?, ? FROM users';
      const now = new Date().toISOString();
      const type = 'system';
      
      if (target === 'agents') {
        query += ' WHERE is_agent = 1';
      } else if (target === 'customers') {
        query += ' WHERE is_agent = 0 AND is_admin = 0 AND is_customer_care = 0';
      }

      const info = db.prepare(query).run(title, message, now, type);
      
      // Send push notifications to target audience
      let pushQuery = 'SELECT id FROM users';
      if (target === 'agents') {
        pushQuery += ' WHERE is_agent = 1';
      } else if (target === 'customers') {
        pushQuery += ' WHERE is_agent = 0 AND is_admin = 0 AND is_customer_care = 0';
      }
      
      const targetUsers = db.prepare(pushQuery).all() as { id: number }[];
      targetUsers.forEach(u => {
        sendPushNotification(u.id, title, message);
      });

      logAdminAction(adminId, 'broadcast_message', 0, `Sent broadcast to ${target}: ${title}`);
      
      res.json({ success: true, count: info.changes, message: `Broadcast sent to ${info.changes} users` });
    } catch (error) {
      console.error('Broadcast error:', error);
      res.status(500).json({ error: 'Failed to send broadcast' });
    }
  });

  // Flutterwave Payment Verification
  app.post('/api/payments/verify', async (req, res) => {
    const { transaction_id, tx_ref, userId } = req.body;
    
    if (!process.env.FLW_SECRET_KEY) {
      return res.status(500).json({ error: 'Flutterwave secret key not configured' });
    }

    try {
      // Check if transaction already processed
      const checkTx = db.prepare('SELECT id FROM transactions WHERE tx_ref = ? AND status = \'success\'').get(tx_ref);
      if (checkTx) {
        return res.json({ success: true, message: 'Transaction already processed' });
      }

      const response = await fetch(`https://api.flutterwave.com/v3/transactions/${transaction_id}/verify`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${process.env.FLW_SECRET_KEY}`,
          'Content-Type': 'application/json'
        }
      });

      const data = await response.json();

      if (data.status === 'success' && data.data.status === 'successful') {
        const amount = data.data.amount;
        const currency = data.data.currency;

        if (currency !== 'NGN') {
          return res.status(400).json({ error: 'Invalid currency' });
        }

        // Update user balance and record transaction
        const updateBalance = db.prepare('UPDATE users SET balance = balance + ? WHERE id = ?');
        const insertTx = db.prepare('INSERT INTO transactions (user_id, type, description, amount, date, status, tx_ref, balance_after) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');

        const transaction = db.transaction(() => {
          updateBalance.run(amount, userId);
          const newBalance = (db.prepare('SELECT balance FROM users WHERE id = ?').get(userId) as any).balance;
          insertTx.run(userId, 'Wallet Fund', `Flutterwave Deposit - ${tx_ref}`, amount, new Date().toISOString(), 'success', tx_ref, newBalance);
        });

        transaction();

        const updatedUser = db.prepare('SELECT id, name, email, balance, hide_balance as hideBalance, daily_transfer_limit as dailyTransferLimit, daily_withdrawal_limit as dailyWithdrawalLimit, total_referred as totalReferred, bvn, last_login_at as lastLoginAt, two_factor_enabled as twoFactorEnabled FROM users WHERE id = ?').get(userId) as any;
        updatedUser.hideBalance = !!updatedUser.hideBalance;
        res.json({ success: true, user: updatedUser });

        // Send Email notification
        sendTransactionEmail(userId, 'Wallet Funded', `Your wallet has been successfully funded with ₦${amount.toLocaleString()} via Flutterwave. Ref: ${tx_ref}`);
      } else {
        res.status(400).json({ error: 'Payment verification failed' });
      }
    } catch (error) {
      console.error('Verification error:', error);
      res.status(500).json({ error: 'Internal server error during verification' });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
  }

  // Global Error Handler Middleware
  app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    console.error('Unhandled Error:', err);
    res.status(err.status || 500).json({
      success: false,
      error: process.env.NODE_ENV === 'production' ? 'Internal Server Error' : err.message
    });
  });

  const PORT = 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
