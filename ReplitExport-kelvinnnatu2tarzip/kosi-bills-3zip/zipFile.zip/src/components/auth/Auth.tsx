import { useState, FormEvent } from 'react';
import { motion } from 'motion/react';
import { toast } from 'react-hot-toast';
import { Mail, Lock, User, ArrowRight, Loader2, Smartphone } from 'lucide-react';
import Logo from '../common/Logo';
import { auth } from '../../firebase';
import { GoogleAuthProvider, signInWithPopup } from 'firebase/auth';

interface AuthProps {
  onLogin: (user: any) => void;
}

export default function Auth({ onLogin }: AuthProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [isForgotMode, setIsForgotMode] = useState(false);
  const [is2FAMode, setIs2FAMode] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [twoFactorEmail, setTwoFactorEmail] = useState('');
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: ''
  });

  const getPasswordStrength = (pass: string) => {
    if (!pass) return 0;
    let strength = 0;
    if (pass.length >= 6) strength += 25;
    if (/[A-Z]/.test(pass)) strength += 25;
    if (/[0-9]/.test(pass)) strength += 25;
    if (/[^A-Za-z0-9]/.test(pass)) strength += 25;
    return strength;
  };

  const strength = getPasswordStrength(formData.password);
  const strengthColor = strength <= 25 ? 'bg-red-500' : strength <= 50 ? 'bg-orange-500' : strength <= 75 ? 'bg-yellow-500' : 'bg-emerald-500';
  const strengthLabel = strength <= 25 ? 'Weak' : strength <= 50 ? 'Fair' : strength <= 75 ? 'Good' : 'Strong';

  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      
      const response = await fetch('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: user.displayName,
          email: user.email,
          profilePhoto: user.photoURL,
          uid: user.uid
        })
      });
      
      const data = await response.json();
      if (response.ok) {
        onLogin(data.user);
        toast.success('Signed in with Google!');
      } else {
        toast.error(data.error || 'Google sign-in failed on server');
      }
    } catch (err) {
      toast.error('Google sign-in failed');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!isLogin && !isForgotMode) {
      if (formData.name.trim().length < 2) {
        toast.error('Name must be at least 2 characters long');
        return;
      }
    }

    const cleanEmail = formData.email.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      toast.error('Please enter a valid email address');
      return;
    }

    if (!isLogin && !isForgotMode) {
      const cleanPhone = formData.phone.replace(/[\s+]/g, '');
      if (cleanPhone.length < 10 || !/^\d+$/.test(cleanPhone)) {
        toast.error('Please enter a valid phone number');
        return;
      }
    }

    if (!isForgotMode) {
      if (formData.password.length < 6) {
        toast.error('Password must be at least 6 characters long');
        return;
      }
    }

    setIsLoading(true);

    try {
      if (is2FAMode) {
        const response = await fetch('/api/auth/verify-2fa', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: twoFactorEmail, code: twoFactorCode })
        });
        const data = await response.json();
        if (response.ok) {
          onLogin(data.user);
          toast.success('Logged in successfully!');
        } else {
          toast.error(data.error || 'Verification failed');
        }
        return;
      }

      let endpoint = '';
      let body = {};
      if (isForgotMode) {
        endpoint = '/api/auth/forgot-password';
        body = { email: cleanEmail };
      } else if (isLogin) {
        endpoint = '/api/auth/login';
        body = { email: cleanEmail, password: formData.password };
      } else {
        endpoint = '/api/auth/register';
        body = { name: formData.name, email: cleanEmail, phone: formData.phone, password: formData.password };
      }

      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const data = await response.json();
      
      if (response.ok) {
        if (isForgotMode) {
          toast.success(data.message || 'Reset link sent to your email');
          setIsForgotMode(false);
          setIsLogin(true);
        } else if (data.requires2FA) {
          setIs2FAMode(true);
          setTwoFactorEmail(data.email);
          toast.success(data.message);
        } else {
          onLogin(data.user);
          toast.success(isLogin ? 'Logged in successfully!' : 'Registered successfully!');
        }
      } else {
        toast.error(data.error || 'Operation failed');
      }
    } catch (err) {
      toast.error('An error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  if (is2FAMode) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-[#020817] flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative overflow-hidden transition-colors duration-300">
        <div className="absolute top-0 left-0 w-full h-96 bg-emerald-900 dark:bg-emerald-950 -skew-y-6 transform origin-top-left -translate-y-24 z-0"></div>
        <div className="relative z-10 sm:mx-auto sm:w-full sm:max-w-md">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="flex justify-center mb-8">
            <Logo className="w-24 h-24" />
          </motion.div>
          <h2 className="text-center text-4xl font-black tracking-tighter text-white mb-2">Verify Identity</h2>
          <p className="text-center text-emerald-100/80 text-sm mb-8 font-medium">Enter the 6-digit code sent to {twoFactorEmail}</p>
        </div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="relative z-10 sm:mx-auto sm:w-full sm:max-w-md">
          <div className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-xl py-10 px-6 shadow-2xl shadow-emerald-900/20 sm:rounded-[2.5rem] sm:px-12 border border-white/20 dark:border-slate-800/50">
            <form className="space-y-6" onSubmit={handleSubmit}>
              <div>
                <label className="block text-xs font-black text-slate-500 dark:text-slate-400 mb-2 uppercase tracking-widest text-center">Verification Code</label>
                <input
                  type="text"
                  maxLength={6}
                  required
                  value={twoFactorCode}
                  onChange={(e) => setTwoFactorCode(e.target.value.replace(/\D/g, ''))}
                  placeholder="000000"
                  className="block w-full text-center text-3xl tracking-[1em] py-4 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 rounded-2xl focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all text-slate-800 dark:text-slate-100 font-black placeholder:text-slate-300 dark:placeholder:text-slate-700"
                />
              </div>

              <button
                type="submit"
                disabled={isLoading || twoFactorCode.length !== 6}
                className="w-full flex justify-center items-center gap-3 py-5 px-6 border border-transparent rounded-2xl text-xl font-black text-white bg-emerald-600 hover:bg-emerald-500 shadow-xl shadow-emerald-500/20 transition-all disabled:opacity-70 active:scale-95"
              >
                {isLoading ? <Loader2 className="w-6 h-6 animate-spin" /> : 'Verify & Login'}
              </button>

              <button
                type="button"
                onClick={() => setIs2FAMode(false)}
                className="w-full text-center text-sm font-bold text-slate-500 hover:text-emerald-600 transition-colors"
              >
                Back to Login
              </button>
            </form>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#020817] flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative overflow-hidden transition-colors duration-300">
      {/* Premium Background Elements */}
      <div className="absolute top-0 left-0 w-full h-96 bg-emerald-900 dark:bg-emerald-950 -skew-y-6 transform origin-top-left -translate-y-24 z-0"></div>
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-emerald-500/10 dark:bg-emerald-500/5 rounded-full blur-3xl -mb-48 -mr-48 z-0"></div>
      
      <div className="relative z-10 sm:mx-auto sm:w-full sm:max-w-md">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-center mb-8"
        >
          <Logo className="w-24 h-24" />
        </motion.div>
        <h2 className="text-center text-4xl font-black tracking-tighter text-white mb-2">
          {isForgotMode ? 'Reset Password' : (isLogin ? 'Welcome back' : 'Create account')}
        </h2>
        <p className="text-center text-emerald-100/80 text-sm mb-8 font-medium">
          {isForgotMode 
            ? 'Enter your email to receive a reset link' 
            : (isLogin ? 'Sign in to access your dashboard' : 'Join Kosi Bills to manage your utilities')}
        </p>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="relative z-10 sm:mx-auto sm:w-full sm:max-w-md"
      >
        <div className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-xl py-10 px-6 shadow-2xl shadow-emerald-900/20 sm:rounded-[2.5rem] sm:px-12 border border-white/20 dark:border-slate-800/50">
          {!isForgotMode && (
            <button
              onClick={handleGoogleSignIn}
              disabled={isLoading}
              className="w-full flex justify-center items-center gap-3 py-4 px-6 border border-slate-300 dark:border-slate-700 rounded-2xl text-lg font-bold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 transition-all disabled:opacity-70 active:scale-95 mb-6"
            >
              <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" className="w-6 h-6" />
              Sign in with Google
            </button>
          )}
          
          {!isForgotMode && (
            <div className="relative mb-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-300 dark:border-slate-700"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white dark:bg-slate-900 text-slate-500">Or continue with</span>
              </div>
            </div>
          )}

          <form className="space-y-6" onSubmit={handleSubmit}>
            {!isLogin && !isForgotMode && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-black text-slate-500 dark:text-slate-400 mb-2 uppercase tracking-widest">Full Name</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none">
                      <User className="h-5 w-5 text-slate-400" />
                    </div>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      className="block w-full pl-12 pr-6 py-4 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 rounded-2xl focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all text-slate-800 dark:text-slate-100 font-bold"
                      placeholder="John Doe"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-black text-slate-500 dark:text-slate-400 mb-2 uppercase tracking-widest">Phone Number</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none">
                      <Smartphone className="h-5 w-5 text-slate-400" />
                    </div>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                      className="block w-full pl-12 pr-6 py-4 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 rounded-2xl focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all text-slate-800 dark:text-slate-100 font-bold"
                      placeholder="08012345678"
                    />
                  </div>
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-black text-slate-500 dark:text-slate-400 mb-2 uppercase tracking-widest">Email Address</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none">
                  <Mail className="h-5 w-5 text-slate-400" />
                </div>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="block w-full pl-12 pr-6 py-4 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 rounded-2xl focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all text-slate-800 dark:text-slate-100 font-bold"
                  placeholder="you@example.com"
                />
              </div>
            </div>

            {!isForgotMode && (
              <div>
                <label className="block text-xs font-black text-slate-500 dark:text-slate-400 mb-2 uppercase tracking-widest">Password</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none">
                    <Lock className="h-5 w-5 text-slate-400" />
                  </div>
                  <input
                    type="password"
                    required
                    value={formData.password}
                    onChange={(e) => setFormData({...formData, password: e.target.value})}
                    className="block w-full pl-12 pr-6 py-4 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 rounded-2xl focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all text-slate-800 dark:text-slate-100 font-bold"
                    placeholder="••••••••"
                  />
                </div>
                {!isLogin && !isForgotMode && formData.password && (
                  <div className="mt-3 space-y-2">
                    <div className="flex justify-between items-center text-[10px] uppercase tracking-wider font-black">
                      <span className="text-slate-500">Security Strength</span>
                      <span className={strengthColor.replace('bg-', 'text-')}>{strengthLabel}</span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${strength}%` }}
                        className={`h-full transition-all duration-500 ${strengthColor}`}
                      />
                    </div>
                  </div>
                )}
                {isLogin && (
                  <div className="mt-2 text-right">
                    <button 
                      type="button"
                      onClick={() => setIsForgotMode(true)}
                      className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:text-emerald-500"
                    >
                      Forgot Password?
                    </button>
                  </div>
                )}
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex justify-center items-center gap-2 py-5 px-6 border border-transparent rounded-2xl shadow-xl shadow-emerald-600/20 text-lg font-black text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 transition-all disabled:opacity-70 active:scale-95"
            >
              {isLoading ? <Loader2 className="w-6 h-6 animate-spin" /> : (isForgotMode ? 'Send Reset Link' : (isLogin ? 'Sign In' : 'Create Account'))}
              {!isLoading && <ArrowRight className="w-5 h-5" />}
            </button>
          </form>

          <div className="mt-10 text-center">
            <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">
              {isForgotMode ? (
                <button 
                  onClick={() => setIsForgotMode(false)} 
                  className="font-black text-emerald-600 dark:text-emerald-400 hover:text-emerald-500 transition-colors"
                >
                  Back to Sign In
                </button>
              ) : (
                <>
                  {isLogin ? "Don't have an account? " : "Already have an account? "}
                  <button 
                    onClick={() => setIsLogin(!isLogin)} 
                    className="font-black text-emerald-600 dark:text-emerald-400 hover:text-emerald-500 transition-colors"
                  >
                    {isLogin ? 'Sign up' : 'Sign in'}
                  </button>
                </>
              )}
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
