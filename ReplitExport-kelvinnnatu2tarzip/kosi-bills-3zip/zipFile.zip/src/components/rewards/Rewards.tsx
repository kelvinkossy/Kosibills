import { useState, useEffect } from 'react';
import { Gift, Award, Star, ChevronRight, Users, Share2, Copy, Loader2 } from 'lucide-react';
import { User } from '../../types';
import toast from 'react-hot-toast';

interface RewardsProps {
  user: User;
}

interface Reward {
  id: number;
  title: string;
  points: number;
  icon: string;
  color: string;
  bg: string;
}

export default function Rewards({ user }: RewardsProps) {
  const [rewards, setRewards] = useState<Reward[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const referralCode = user.referralCode || `KOSI-${(user.name || 'USR').substring(0, 3).toUpperCase()}${String(user.id).substring(0, 4)}`;

  useEffect(() => {
    const fetchRewards = async () => {
      try {
        const response = await fetch('/api/rewards');
        const data = await response.json();
        if (data.success) {
          setRewards(data.rewards);
        }
      } catch (err) {
        toast.error('Failed to load rewards');
      } finally {
        setIsLoading(false);
      }
    };
    fetchRewards();
  }, []);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(referralCode);
    toast.success('Referral code copied!');
  };

  const handleShareWhatsApp = () => {
    const text = `Join me on Kosi Bills! Use my referral code ${referralCode} and we both get ₦100 airtime credit after your first ₦2,000+ transaction. Download now: https://kosibills.com`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  const handleApplyAgent = async () => {
    try {
      const response = await fetch('/api/user/apply-agent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id })
      });
      const data = await response.json();
      if (data.success) {
        toast.success('Application submitted! We will contact you soon.');
      } else {
        toast.error(data.error || 'Failed to submit application');
      }
    } catch (err) {
      toast.error('Network error');
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8 pb-24">
      {/* Points Header */}
      <div className="bg-white/40 dark:bg-slate-800/40 backdrop-blur-xl border border-white/60 dark:border-slate-700/60 rounded-[2rem] p-8 sm:p-10 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-40 h-40 bg-emerald-500/10 rounded-full blur-2xl -ml-10 -mb-10 pointer-events-none" />
        
        <div className="relative z-10 flex flex-col items-center text-center space-y-4">
          <div className="w-20 h-20 bg-white/60 dark:bg-slate-900/60 backdrop-blur-md rounded-full flex items-center justify-center border border-white/50 dark:border-slate-700/50 shadow-sm">
            <Award className="w-10 h-10 text-amber-500" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest mb-1">Available Points</h2>
            <p className="text-5xl font-black tracking-tighter text-slate-800 dark:text-white">12,450</p>
          </div>
          <p className="text-slate-600 dark:text-slate-300 text-sm font-medium">Earn more points by completing transactions</p>
        </div>
      </div>

      {/* Referral Program */}
      <div className="bg-white/40 dark:bg-slate-800/40 backdrop-blur-xl border border-white/60 dark:border-slate-700/60 rounded-[2rem] p-6 sm:p-8 shadow-sm">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
            <Gift className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-slate-800 dark:text-white">Refer & Earn</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">Get ₦100 airtime for every friend</p>
          </div>
        </div>
        
        <div className="bg-emerald-50 dark:bg-emerald-900/10 border border-emerald-100 dark:border-emerald-800/30 rounded-2xl p-4 mb-6">
          <p className="text-sm text-emerald-800 dark:text-emerald-200 font-medium">
            Invite friends to Kosi Bills. When they make their first transaction of ₦2,000 or more, you both get ₦100 airtime credit instantly!
          </p>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Your Referral Code</label>
            <div className="flex items-center gap-2">
              <div className="flex-1 bg-white/60 dark:bg-slate-900/60 border border-white/50 dark:border-slate-700/50 rounded-xl px-4 py-3 font-mono font-bold text-lg text-slate-800 dark:text-white tracking-widest text-center">
                {referralCode}
              </div>
              <button 
                onClick={handleCopyCode}
                className="p-3 bg-white/60 dark:bg-slate-900/60 border border-white/50 dark:border-slate-700/50 hover:bg-white dark:hover:bg-slate-800 rounded-xl transition-colors text-slate-600 dark:text-slate-300"
              >
                <Copy className="w-6 h-6" />
              </button>
            </div>
          </div>
          <button 
            onClick={handleShareWhatsApp}
            className="w-full py-3 bg-[#25D366] hover:bg-[#128C7E] text-white rounded-xl font-bold transition-colors flex items-center justify-center gap-2 shadow-lg shadow-[#25D366]/20"
          >
            <Share2 className="w-5 h-5" /> Share via WhatsApp
          </button>
        </div>
      </div>

      {/* Kosi Agent Program */}
      <div className="bg-white/40 dark:bg-slate-800/40 backdrop-blur-xl border border-white/60 dark:border-slate-700/60 rounded-[2rem] p-6 sm:p-8 shadow-sm">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-slate-800 dark:text-white">Kosi Agent Program</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">For Hostel & Market Leaders</p>
          </div>
        </div>
        
        <div className="space-y-4 mb-6">
          <p className="text-sm text-slate-600 dark:text-slate-300">
            Become a Kosi Agent and earn commissions on every transaction you process for others. Perfect for student leaders, market heads, and community organizers.
          </p>
          <ul className="text-sm text-slate-600 dark:text-slate-300 space-y-2">
            <li className="flex items-center gap-2"><Star className="w-4 h-4 text-amber-500" /> Discounted wholesale rates on Airtime & Data</li>
            <li className="flex items-center gap-2"><Star className="w-4 h-4 text-amber-500" /> Dedicated agent support line</li>
            <li className="flex items-center gap-2"><Star className="w-4 h-4 text-amber-500" /> Monthly performance bonuses</li>
          </ul>
        </div>

        {user.isAgent ? (
          <div className="bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-100 dark:border-indigo-800/50 rounded-xl p-4 text-center">
            <p className="font-bold text-indigo-600 dark:text-indigo-400">You are an active Kosi Agent!</p>
            <p className="text-xs text-indigo-500 dark:text-indigo-300 mt-1">Wholesale rates are automatically applied to your transactions.</p>
          </div>
        ) : (
          <button 
            onClick={handleApplyAgent}
            className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition-colors shadow-lg shadow-indigo-600/20"
          >
            Apply to be an Agent
          </button>
        )}
      </div>

      {/* Available Offers */}
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-slate-800 dark:text-white px-2">Redeem Points</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {isLoading ? (
            <div className="col-span-2 flex justify-center p-8">
              <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
            </div>
          ) : rewards.map((offer, i) => {
            const Icon = { Star, Gift, Award }[offer.icon] || Star;
            return (
              <button key={offer.id} className="bg-white/60 dark:bg-slate-900/60 border border-white/50 dark:border-slate-700/50 rounded-2xl p-5 flex items-center justify-between hover:bg-white dark:hover:bg-slate-800 transition-colors text-left group">
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${offer.bg} ${offer.color} group-hover:scale-110 transition-transform`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-800 dark:text-white">{offer.title}</h4>
                    <p className="text-sm font-bold text-emerald-600 dark:text-emerald-400">{offer.points} pts</p>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-400" />
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
