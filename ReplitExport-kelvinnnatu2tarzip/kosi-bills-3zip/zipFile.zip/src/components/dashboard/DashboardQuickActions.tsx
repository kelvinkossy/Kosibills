import React from 'react';
import { View } from '../../types';
import { Zap, Smartphone, Wifi, Lightbulb, Tv, PhoneCall } from 'lucide-react';

interface QuickActionsProps {
  setView: (view: View) => void;
  userPhone: string;
}

export default function QuickActions({ setView, userPhone }: QuickActionsProps) {
  const quickActions = [
    { name: 'Airtime', icon: PhoneCall, view: 'airtime' as View, color: 'text-blue-600 dark:text-blue-400', bg: 'bg-blue-50 dark:bg-blue-900/20', hover: 'hover:bg-blue-100 dark:hover:bg-blue-900/30' },
    { name: 'Data', icon: Wifi, view: 'data' as View, color: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-emerald-50 dark:bg-emerald-900/20', hover: 'hover:bg-emerald-100 dark:hover:bg-emerald-900/30' },
    { name: 'Electricity', icon: Lightbulb, view: 'electricity' as View, color: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-50 dark:bg-amber-900/20', hover: 'hover:bg-amber-100 dark:hover:bg-amber-900/30' },
    { name: 'Cable TV', icon: Tv, view: 'cable' as View, color: 'text-purple-600 dark:text-purple-400', bg: 'bg-purple-50 dark:bg-purple-900/20', hover: 'hover:bg-purple-100 dark:hover:bg-purple-900/30' },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <button 
          onClick={() => setView('airtime')}
          className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center gap-4 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors group"
        >
          <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 flex items-center justify-center group-hover:scale-110 transition-transform">
            <Smartphone className="w-5 h-5" />
          </div>
          <div className="text-left">
            <p className="font-bold text-slate-800 dark:text-white">Buy Airtime for Self</p>
            <p className="text-xs text-slate-500 dark:text-slate-400">{userPhone}</p>
          </div>
        </button>
        <button 
          onClick={() => setView('data')}
          className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center gap-4 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors group"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform">
            <Wifi className="w-5 h-5" />
          </div>
          <div className="text-left">
            <p className="font-bold text-slate-800 dark:text-white">Buy Data for Self</p>
            <p className="text-xs text-slate-500 dark:text-slate-400">{userPhone}</p>
          </div>
        </button>
      </div>

      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">Quick Services</h2>
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/20 px-3 py-1.5 rounded-full">
            <Zap className="w-3 h-3 fill-current" /> Instant Delivery
          </div>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6">
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <button
                key={action.name}
                onClick={() => setView(action.view)}
                className="premium-card p-6 flex flex-col items-center justify-center gap-4 group active:scale-95"
              >
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${action.bg} ${action.color} ${action.hover} transition-all duration-300 group-hover:rotate-6`}>
                  <Icon className="w-8 h-8" />
                </div>
                <span className="font-bold text-slate-700 dark:text-slate-300 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">{action.name}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
