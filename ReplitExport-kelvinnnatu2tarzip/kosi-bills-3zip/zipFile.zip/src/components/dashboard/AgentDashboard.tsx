import React, { useState, useEffect } from 'react';
import { User, Transaction } from '../../types';
import { motion } from 'framer-motion';
import { Wallet, Users, ArrowUpRight, ArrowDownRight, Activity } from 'lucide-react';
import toast from 'react-hot-toast';
import AIInsights from '../ai/AIInsights';

interface AgentDashboardProps {
  user: User;
}

export default function AgentDashboard({ user }: AgentDashboardProps) {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAgentData = async () => {
      try {
        const res = await fetch(`/api/transactions/${user.id}`);
        const data = await res.json();
        if (data.success) {
          setTransactions(data.transactions);
        }
      } catch (error) {
        toast.error('Failed to fetch agent data');
      } finally {
        setLoading(false);
      }
    };
    fetchAgentData();
  }, [user.id]);

  const totalCommission = transactions
    .filter(t => t.type === 'Commission' && t.status === 'success')
    .reduce((sum, t) => sum + t.amount, 0);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8"
    >
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-slate-800 dark:text-white">Agent Dashboard</h2>
      </div>

      <AIInsights 
        title="Agent AI Assistant"
        context="You are analyzing the performance of a Kosi Bills agent. The data contains the agent's balance, total commission, total transactions, and recent transactions. Provide insights on their performance, trends, and recommendations to increase their earnings."
        data={{
          balance: user.balance,
          totalCommission: totalCommission,
          totalTransactions: transactions.length,
          recentTransactions: transactions.slice(0, 5)
        }}
      />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-xl">
              <Wallet className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">Agent Balance</p>
              <h3 className="text-2xl font-bold text-slate-800 dark:text-white">₦{user.balance.toLocaleString()}</h3>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-xl">
              <Activity className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">Total Commission</p>
              <h3 className="text-2xl font-bold text-slate-800 dark:text-white">₦{totalCommission.toLocaleString()}</h3>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 rounded-xl">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">Referral Code</p>
              <h3 className="text-xl font-bold text-slate-800 dark:text-white">{user.referralCode || 'N/A'}</h3>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-200 dark:border-slate-700">
          <h3 className="text-lg font-bold text-slate-800 dark:text-white">Recent Agent Activity</h3>
        </div>
        <div className="p-6">
          {loading ? (
            <div className="animate-pulse space-y-4">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-16 bg-slate-100 dark:bg-slate-700/50 rounded-xl"></div>
              ))}
            </div>
          ) : transactions.length > 0 ? (
            <div className="space-y-4">
              {transactions.slice(0, 10).map((tx) => (
                <div key={tx.id} className="flex items-center justify-between p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700/50">
                  <div className="flex items-center gap-4">
                    <div className={`p-2 rounded-lg ${
                      tx.amount > 0 
                        ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400'
                        : 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400'
                    }`}>
                      {tx.amount > 0 ? <ArrowDownRight className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
                    </div>
                    <div>
                      <p className="font-bold text-slate-800 dark:text-white">{tx.type}</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">{new Date(tx.date).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`font-bold ${tx.amount > 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-800 dark:text-white'}`}>
                      {tx.amount > 0 ? '+' : ''}₦{Math.abs(tx.amount).toLocaleString()}
                    </p>
                    <p className={`text-xs capitalize ${
                      tx.status === 'success' ? 'text-emerald-500' :
                      tx.status === 'pending' ? 'text-amber-500' : 'text-red-500'
                    }`}>
                      {tx.status}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-slate-500 dark:text-slate-400">
              No agent activity yet.
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
