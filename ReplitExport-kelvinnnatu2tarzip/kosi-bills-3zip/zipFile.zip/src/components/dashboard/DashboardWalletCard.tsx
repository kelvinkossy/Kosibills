import React from 'react';
import { Wallet, Eye, EyeOff, RefreshCw, ShieldCheck, Zap, ArrowUpRight, ArrowDownLeft, Copy } from 'lucide-react';
import { User } from '../../types';
import { toast } from 'react-hot-toast';

interface WalletCardProps {
  user: User;
  hideBalance: boolean;
  toggleBalanceVisibility: () => void;
  handleRefresh: () => void;
  isLoading: boolean;
  setShowBankDetails: (show: boolean) => void;
  showBankDetails: boolean;
  setShowFundModal: (show: boolean) => void;
  isFunding: boolean;
}

export default function WalletCard({
  user,
  hideBalance,
  toggleBalanceVisibility,
  handleRefresh,
  isLoading,
  setShowBankDetails,
  showBankDetails,
  setShowFundModal,
  isFunding
}: WalletCardProps) {
  return (
    <div className="bg-white/30 dark:bg-slate-900/30 backdrop-blur-2xl border border-white/50 dark:border-slate-700/50 rounded-[2.5rem] p-8 sm:p-10 shadow-xl shadow-slate-200/20 dark:shadow-none relative overflow-hidden group">
      <div className="absolute top-0 right-0 -mt-10 -mr-10 w-64 h-64 bg-emerald-400/10 dark:bg-emerald-500/10 rounded-full blur-3xl group-hover:scale-110 transition-transform duration-700 pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 -mb-10 -ml-10 w-64 h-64 bg-blue-400/10 dark:bg-blue-500/10 rounded-full blur-3xl group-hover:scale-110 transition-transform duration-700 pointer-events-none"></div>
      
      <div className="relative z-10 flex flex-col sm:flex-row sm:items-end justify-between gap-8">
        <div className="space-y-4">
          <div className="flex flex-wrap gap-2">
            <div className="bg-white/50 dark:bg-slate-800/50 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5 border border-slate-200/50 dark:border-slate-700/50 text-slate-600 dark:text-slate-300">
              <ShieldCheck className="w-3 h-3" /> {user.tier} Account
            </div>
            {user.isLiveMode && (
              <div className="bg-red-100/50 dark:bg-red-900/30 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5 border border-red-200/50 dark:border-red-800/50 text-red-600 dark:text-red-400">
                <Zap className="w-3 h-3 fill-current" /> Live Mode
              </div>
            )}
          </div>
          <div>
            <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400 font-medium mb-2">
              <Wallet className="w-4 h-4" />
              Available Balance
              <button 
                onClick={toggleBalanceVisibility}
                className="ml-1 p-1 hover:bg-slate-200/50 dark:hover:bg-slate-700/50 rounded-full transition-colors"
                aria-label={hideBalance ? "Show balance" : "Hide balance"}
              >
                {hideBalance ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
              <button 
                onClick={handleRefresh} 
                disabled={isLoading}
                className="ml-1 p-1 hover:bg-slate-200/50 dark:hover:bg-slate-700/50 rounded-full transition-colors disabled:opacity-50"
                title="Refresh Balance"
                aria-label="Refresh balance"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
              </button>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-4xl sm:text-6xl font-black tracking-tighter text-slate-800 dark:text-white">
                {hideBalance ? '₦ • • • • •' : `₦${user?.balance ? Number(user.balance).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '0.00'}`}
              </span>
            </div>
          </div>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => setShowBankDetails(!showBankDetails)}
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 bg-white/50 dark:bg-slate-800/50 backdrop-blur-md text-slate-700 dark:text-slate-200 px-8 py-4 rounded-2xl font-bold hover:bg-white/80 dark:hover:bg-slate-700/80 transition-all border border-slate-200/50 dark:border-slate-700/50 active:scale-95"
          >
            <ArrowUpRight className="w-5 h-5" />
            Bank Transfer
          </button>
          <button 
            onClick={() => setShowFundModal(true)}
            disabled={isFunding}
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-8 py-4 rounded-2xl font-bold hover:opacity-90 transition-all shadow-lg active:scale-95 disabled:opacity-70"
          >
            <ArrowDownLeft className="w-5 h-5" />
            {isFunding ? "Processing..." : "Fund Wallet"}
          </button>
        </div>
      </div>
    </div>
  );
}
