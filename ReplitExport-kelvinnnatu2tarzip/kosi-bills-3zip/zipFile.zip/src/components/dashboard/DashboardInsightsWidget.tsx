import React from 'react';
import { BrainCircuit } from 'lucide-react';

interface DashboardInsightsWidgetProps {
  aiTip: string;
  topExpenseCategory: string;
  budgetUsedPercent: number;
  budgetLimit: number;
}

export default function DashboardInsightsWidget({ aiTip, topExpenseCategory, budgetUsedPercent, budgetLimit }: DashboardInsightsWidgetProps) {
  return (
    <div className="bg-white/40 dark:bg-slate-800/40 backdrop-blur-xl border border-white/60 dark:border-slate-700/60 rounded-2xl p-4 shadow-sm">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-2">
          <BrainCircuit className="w-4 h-4 text-indigo-500" />
          AI Insights
        </h2>
      </div>
      <div className="space-y-3">
        <div className="bg-white/60 dark:bg-slate-900/60 border border-white/50 dark:border-slate-700/50 rounded-xl p-3">
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">Top Expense Category</p>
          <p className="font-bold text-sm text-slate-800 dark:text-white">{topExpenseCategory}</p>
        </div>
        <div className="bg-white/60 dark:bg-slate-900/60 border border-white/50 dark:border-slate-700/50 rounded-xl p-3">
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">Budget Used</p>
          <div className="flex items-center gap-2">
            <div className="flex-1 h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
              <div className="h-full bg-indigo-500" style={{ width: `${budgetUsedPercent}%` }}></div>
            </div>
            <span className="font-bold text-xs text-slate-800 dark:text-white">{budgetUsedPercent}%</span>
          </div>
        </div>
        <div className="bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-100 dark:border-indigo-800/50 rounded-xl p-3">
          <p className="text-xs text-indigo-800 dark:text-indigo-200 font-medium">{aiTip}</p>
        </div>
      </div>
    </div>
  );
}
