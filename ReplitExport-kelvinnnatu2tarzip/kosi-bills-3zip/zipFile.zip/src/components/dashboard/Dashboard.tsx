import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'react-hot-toast';
import { View, User, Transaction } from '../../types';
import { 
  ArrowUpRight, 
  ArrowDownLeft, 
  Wallet, 
  PhoneCall, 
  Wifi, 
  Lightbulb, 
  Tv,
  ChevronRight,
  Clock,
  Loader2,
  Zap,
  ShieldCheck,
  TrendingUp,
  AlertCircle,
  RefreshCw,
  PieChart,
  BrainCircuit,
  BellRing,
  Copy,
  Eye,
  EyeOff,
  UserPlus,
  Gift,
  Smartphone
} from 'lucide-react';
import DashboardWalletCard from './DashboardWalletCard';
import DashboardQuickActions from './DashboardQuickActions';
import DashboardInsightsWidget from './DashboardInsightsWidget';
import DashboardRecentTransactions from './DashboardRecentTransactions';
import { getCurrentSeason, getSeasonStyles } from '../../utils/seasons';
import { storage } from '../../utils/storage';

interface DashboardProps {
  setView: (view: View) => void;
  user: User;
  setUser: (user: User) => void;
}

declare global {
  interface Window {
    FlutterwaveCheckout: any;
  }
}

export default function Dashboard({ setView, user, setUser }: DashboardProps) {
  const [recentTransactions, setRecentTransactions] = useState<Transaction[]>([]);
  const [subWallets, setSubWallets] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isFunding, setIsFunding] = useState(false);
  const [showBankDetails, setShowBankDetails] = useState(false);
  const [showFundModal, setShowFundModal] = useState(false);
  const [fundAmount, setFundAmount] = useState('1000');
  const [hideBalance, setHideBalance] = useState(user.hideBalance || false);
  console.log('Dashboard render, hideBalance:', hideBalance, 'user.hideBalance:', user.hideBalance);
  const [showPinModal, setShowPinModal] = useState(!user.pin);

  const fetchRecent = async () => {
    try {
      const response = await fetch(`/api/transactions/${user.id}`);
      const data = await response.json();
      if (data.success) {
        setRecentTransactions((data.transactions || []).slice(0, 5));
      }
      
      const swResponse = await fetch(`/api/sub-wallets/${user.id}`);
      const swData = await swResponse.json();
      if (swData.success) {
        setSubWallets([...(swData.owned || []), ...(swData.shared || [])].slice(0, 2));
      }
    } catch (error) {
      console.error("Failed to fetch recent transactions:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    console.log('Dashboard useEffect called, user.hideBalance:', user.hideBalance);
    if (user?.id) {
      fetchRecent();
    }
    setHideBalance(user.hideBalance || false);
  }, [user?.id, user.hideBalance]);

  const handleRefresh = async () => {
    setIsLoading(true);
    try {
      // Refresh user data (balance)
      const userResponse = await fetch(`/api/user/${user.id}`);
      const userData = await userResponse.json();
      if (userData.success) {
        setUser(userData.user);
        storage.set('kosi_user', JSON.stringify(userData.user));
      } else {
        throw new Error(userData.error || 'Failed to fetch user');
      }
      // Refresh transactions
      await fetchRecent();
      toast.success("Dashboard refreshed");
    } catch (error) {
      toast.error("Failed to refresh");
      setIsLoading(false);
    }
  };

  const handleFundWallet = async () => {
    const amount = fundAmount;
    if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) return;
    
    setShowFundModal(false);

    const tx_ref = `KOSI-${Date.now()}`;
    const publicKey = import.meta.env.VITE_FLW_PUBLIC_KEY;

    if (!publicKey) {
      toast.error("Payment gateway not configured. Please contact support.");
      return;
    }

    window.FlutterwaveCheckout({
      public_key: publicKey,
      tx_ref: tx_ref,
      amount: Number(amount),
      currency: "NGN",
      payment_options: "card, banktransfer, ussd",
      customer: {
        email: user.email,
        name: user.name,
      },
      customizations: {
        title: "Kosi Bills",
        description: "Wallet Funding",
        logo: "https://picsum.photos/seed/kosi/200/200",
      },
      callback: async (data: any) => {
        setIsFunding(true);
        try {
          const response = await fetch('/api/payments/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              transaction_id: data.transaction_id,
              tx_ref: tx_ref,
              userId: user.id
            })
          });
          const result = await response.json();
          if (result.success) {
            setUser(result.user);
            storage.set('kosi_user', JSON.stringify(result.user));
            toast.success("Wallet funded successfully!");
            // Refresh transactions
            const txResponse = await fetch(`/api/transactions/${user.id}`);
            const txData = await txResponse.json();
            if (txData.success) setRecentTransactions((txData.transactions || []).slice(0, 5));
          } else {
            toast.error("Payment verification failed: " + result.error);
          }
        } catch (err) {
          toast.error("Error verifying payment");
        } finally {
          setIsFunding(false);
        }
      },
      onclose: () => {
        console.log("Payment modal closed");
      }
    });
  };

  const quickActions = [
    { name: 'Airtime', icon: PhoneCall, view: 'airtime' as View, color: 'text-blue-600 dark:text-blue-400', bg: 'bg-blue-50 dark:bg-blue-900/20', hover: 'hover:bg-blue-100 dark:hover:bg-blue-900/30' },
    { name: 'Data', icon: Wifi, view: 'data' as View, color: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-emerald-50 dark:bg-emerald-900/20', hover: 'hover:bg-emerald-100 dark:hover:bg-emerald-900/30' },
    { name: 'Electricity', icon: Lightbulb, view: 'electricity' as View, color: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-50 dark:bg-amber-900/20', hover: 'hover:bg-amber-100 dark:hover:bg-amber-900/30' },
    { name: 'Cable TV', icon: Tv, view: 'cable' as View, color: 'text-purple-600 dark:text-purple-400', bg: 'bg-purple-50 dark:bg-purple-900/20', hover: 'hover:bg-purple-100 dark:hover:bg-purple-900/30' },
  ];

  const budgetLimit = 50000;

  // Calculate dynamic insights
  const { thisMonthSpent, lastMonthSpent, topExpenseCategory, budgetUsedPercent, aiTip, upcomingBillNudge } = useMemo(() => {
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    
    const thisMonthTxs = recentTransactions.filter(tx => {
      const d = new Date(tx.date);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    });

    const lastMonthTxs = recentTransactions.filter(tx => {
      const d = new Date(tx.date);
      const prevMonth = currentMonth === 0 ? 11 : currentMonth - 1;
      const prevYear = currentMonth === 0 ? currentYear - 1 : currentYear;
      return d.getMonth() === prevMonth && d.getFullYear() === prevYear;
    });

    const thisMonthSpentCalc = thisMonthTxs.filter(tx => tx.amount < 0).reduce((acc, tx) => acc + Math.abs(tx.amount), 0);
    const lastMonthSpentCalc = lastMonthTxs.filter(tx => tx.amount < 0).reduce((acc, tx) => acc + Math.abs(tx.amount), 0);
    
    // Calculate top expense category
    const expensesByCategory = thisMonthTxs.filter(tx => tx.amount < 0).reduce((acc, tx) => {
      const cat = tx.category || 'Other';
      acc[cat] = (acc[cat] || 0) + Math.abs(tx.amount);
      return acc;
    }, {} as Record<string, number>);
    
    const topCategory = Object.entries(expensesByCategory).sort((a, b) => (b[1] as number) - (a[1] as number))[0]?.[0] || 'None';
    
    const budgetPercent = Math.min(100, Math.round((thisMonthSpentCalc / budgetLimit) * 100));
    
    let tip = "You're doing great! Keep tracking your expenses.";
    if (thisMonthSpentCalc > lastMonthSpentCalc && lastMonthSpentCalc > 0) {
      const percentIncrease = Math.round(((thisMonthSpentCalc - lastMonthSpentCalc) / lastMonthSpentCalc) * 100);
      tip = `You spent ${percentIncrease}% more this month compared to last month. Consider reviewing your ${topCategory} expenses.`;
    } else if (thisMonthSpentCalc < lastMonthSpentCalc) {
      tip = `Great job! You spent less this month compared to last month.`;
    }

    // Dynamic Home Screen Nudge Logic
    let nudge = null;
    const utilityTxs = recentTransactions.filter(tx => tx.category === 'Utilities' || tx.category === 'Entertainment');
    if (utilityTxs.length > 0) {
      const lastUtility = utilityTxs[0];
      const amount = Math.abs(lastUtility.amount);
      const type = lastUtility.type || 'Utility';
      nudge = {
        message: `Your ₦${amount.toLocaleString()} ${type} bill is usually due in 3 days. Shall I set aside the funds?`,
        amount: amount,
        type: type
      };
    }

    return {
      thisMonthSpent: thisMonthSpentCalc,
      lastMonthSpent: lastMonthSpentCalc,
      topExpenseCategory: topCategory,
      budgetUsedPercent: budgetPercent,
      aiTip: tip,
      upcomingBillNudge: nudge
    };
  }, [recentTransactions]);

  const toggleBalanceVisibility = async () => {
    const newValue = !hideBalance;
    console.log('Toggling balance visibility to:', newValue);
    try {
      const response = await fetch('/api/user/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, hideBalance: newValue })
      });
      const data = await response.json();
      console.log('Response from server:', data);
      if (data.success) {
        setHideBalance(newValue);
        setUser(data.user);
        storage.set('kosi_user', JSON.stringify(data.user));
      }
    } catch (err) {
      console.error('Failed to toggle balance visibility', err);
    }
  };

  const handleSetPin = async (e: React.FormEvent) => {
    e.preventDefault();
    // ... PIN setting logic ...
    // For now just close the modal and update user
    setShowPinModal(false);
    toast.success('PIN set successfully!');
  };

  const season = getCurrentSeason();
  const seasonStyles = getSeasonStyles(season);

  return (
    <div className="h-full overflow-y-auto p-4 sm:p-6 space-y-4">
      {/* Seasonal Greeting & Referral Banner in a grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className={`${seasonStyles.bg} border border-white/20 dark:border-slate-800/20 rounded-2xl p-4 flex items-center gap-3 shadow-sm`}
        >
          <span className="text-xl">{seasonStyles.icon}</span>
          <div>
            <h4 className={`font-bold text-sm ${seasonStyles.accent}`}>{seasonStyles.greeting}</h4>
            <p className="text-[10px] text-slate-500 dark:text-slate-400">Enjoy special rewards!</p>
          </div>
        </motion.div>
        
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-gradient-to-r from-emerald-600 to-teal-600 rounded-2xl p-4 text-white flex items-center justify-between gap-4 overflow-hidden relative"
        >
          <div className="flex items-center gap-3 relative z-10">
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-md">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black tracking-tight">Invite & Earn ₦500</h3>
              <p className="text-emerald-100/80 text-[10px] font-medium">Code: <span className="font-black text-white">{user.referralCode || 'KOSI-REF'}</span></p>
            </div>
          </div>
          <button 
            onClick={() => {
              navigator.clipboard.writeText(user.referralCode || 'KOSI-REF');
              toast.success('Referral code copied!');
            }}
            className="px-4 py-2 bg-white text-emerald-600 rounded-xl font-black text-[10px] hover:bg-emerald-50 transition-colors shadow-lg relative z-10"
          >
            Copy
          </button>
        </motion.div>
      </div>

      {/* Wallet Card */}
      <DashboardWalletCard 
        user={user}
        hideBalance={hideBalance}
        toggleBalanceVisibility={toggleBalanceVisibility}
        handleRefresh={handleRefresh}
        isLoading={isLoading}
        setShowBankDetails={setShowBankDetails}
        showBankDetails={showBankDetails}
        setShowFundModal={setShowFundModal}
        isFunding={isFunding}
      />

      {/* Quick Actions & Recent Transactions in a grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <DashboardQuickActions 
          setView={setView}
          userPhone={user.phone}
        />
        <DashboardRecentTransactions 
          transactions={recentTransactions}
          isLoading={isLoading}
          setView={setView}
        />
      </div>

      {/* AI Insights & Sub-Wallets in a grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <DashboardInsightsWidget 
          aiTip={aiTip}
          topExpenseCategory={topExpenseCategory}
          budgetUsedPercent={budgetUsedPercent}
          budgetLimit={budgetLimit}
        />
        {/* Sub-Wallets Section - made more compact */}
        <div className="bg-white/40 dark:bg-slate-800/40 backdrop-blur-xl border border-white/60 dark:border-slate-700/60 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-bold text-slate-800 dark:text-white">Family & Office Wallets</h2>
            <button onClick={() => setView('sub-wallets')} className="text-indigo-600 dark:text-indigo-400 font-bold text-xs">Manage</button>
          </div>
          <div className="grid grid-cols-1 gap-2">
            {subWallets.length > 0 ? subWallets.map((wallet, idx) => (
              <div key={wallet.id} className="bg-white/60 dark:bg-slate-900/60 border border-white/50 dark:border-slate-700/50 rounded-xl p-3 flex items-center justify-between cursor-pointer" onClick={() => setView('sub-wallets')}>
                <p className="font-bold text-xs text-slate-800 dark:text-white">{wallet.name}</p>
                <p className="font-black text-xs text-emerald-600 dark:text-emerald-400">₦{wallet.balance.toLocaleString()}</p>
              </div>
            )) : (
              <p className="text-xs text-slate-500 dark:text-slate-400 text-center py-2">No sub-wallets yet.</p>
            )}
          </div>
        </div>
      </div>
      
      {/* ... (rest of the modals) ... */}
    </div>
  );
}
