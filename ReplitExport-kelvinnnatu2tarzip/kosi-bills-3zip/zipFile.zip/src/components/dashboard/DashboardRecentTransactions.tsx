import React from 'react';
import { Transaction } from '../../types';
import { ArrowUpRight, ArrowDownLeft, Clock, ChevronRight } from 'lucide-react';

interface RecentTransactionsProps {
  transactions: Transaction[];
  isLoading: boolean;
  setView: (view: any) => void;
}

export default function RecentTransactions({ transactions, isLoading, setView }: RecentTransactionsProps) {
  return (
    <div className="premium-card overflow-hidden">
      <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
        <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">Recent Activity</h2>
        <button 
          onClick={() => setView('history')}
          aria-label="View full transaction history"
          className="text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 font-bold text-sm flex items-center gap-1 transition-colors"
        >
          View History <ChevronRight className="w-4 h-4" />
        </button>
      </div>
      <div className="divide-y divide-slate-100 dark:divide-slate-800">
        {isLoading ? (
          <div className="p-6 space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center justify-between animate-pulse">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-slate-200 dark:bg-slate-800"></div>
                  <div className="space-y-2">
                    <div className="h-4 w-32 bg-slate-200 dark:bg-slate-800 rounded"></div>
                    <div className="h-3 w-24 bg-slate-100 dark:bg-slate-800/50 rounded"></div>
                  </div>
                </div>
                <div className="h-5 w-16 bg-slate-200 dark:bg-slate-800 rounded"></div>
              </div>
            ))}
          </div>
        ) : transactions.length > 0 ? (
            transactions.map((tx) => (
            <div key={tx.id} className="p-6 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  tx.amount > 0 ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                }`}>
                  {tx.amount > 0 ? <ArrowDownLeft className="w-6 h-6" /> : <ArrowUpRight className="w-6 h-6" />}
                </div>
                <div>
                  <p className="font-bold text-slate-800 dark:text-slate-200">{tx.description}</p>
                  <div className="flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400 mt-1">
                    <Clock className="w-3 h-3" />
                    {new Date(tx.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </div>
              <div className={`text-lg font-black ${tx.amount > 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-800 dark:text-slate-100'}`}>
                {tx.amount > 0 ? '+' : ''}₦{Math.abs(tx.amount).toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
            </div>
          ))
        ) : (
          <div className="p-12 text-center flex flex-col items-center justify-center">
            <div className="w-16 h-16 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mb-4">
              <Clock className="w-8 h-8 text-slate-400" />
            </div>
            <p className="text-slate-500 dark:text-slate-400 font-bold">No recent activity</p>
            <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">Your transactions will appear here</p>
          </div>
        )}
      </div>
    </div>
  );
}
