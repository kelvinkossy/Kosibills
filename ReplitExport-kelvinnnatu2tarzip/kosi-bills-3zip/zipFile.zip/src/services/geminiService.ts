import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function getAIInsight(prompt: string, context: any) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Context: ${JSON.stringify(context)}. Prompt: ${prompt}`,
    });
    return response.text;
  } catch (error) {
    console.error("AI Error:", error);
    return null;
  }
}
