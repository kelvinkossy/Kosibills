import { GoogleGenAI } from "@google/genai";

let ai: GoogleGenAI | null = null;

function getAI(): GoogleGenAI | null {
  if (ai) return ai;
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  try {
    ai = new GoogleGenAI({ apiKey });
    return ai;
  } catch {
    return null;
  }
}

export async function getAIInsight(prompt: string, context: any): Promise<string | null> {
  const client = getAI();
  if (!client) return null;
  try {
    const response = await client.models.generateContent({
      model: "gemini-2.0-flash",
      contents: `Context: ${JSON.stringify(context)}. Prompt: ${prompt}`,
    });
    return response.text ?? null;
  } catch (error) {
    console.error("AI Error:", error);
    return null;
  }
}
