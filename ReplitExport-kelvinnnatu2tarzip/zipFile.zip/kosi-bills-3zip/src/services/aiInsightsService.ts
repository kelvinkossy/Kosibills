export const analyzeDataLocally = (data: any) => {
  let insights = "### 📊 Financial Health & Trends\n\n";
  
  // Balance Analysis
  if (data.balance !== undefined) {
    const bal = parseFloat(data.balance);
    insights += `* **Current Liquidity:** ₦${bal.toLocaleString()}. `;
    if (bal > 50000) {
      insights += "Your liquidity is strong. You're well-positioned for upcoming expenses.\n";
    } else if (bal > 10000) {
      insights += "Your balance is stable. Keep an eye on your upcoming utility renewals.\n";
    } else {
      insights += "⚠️ **Alert:** Your balance is running low. Consider a top-up to avoid service disruptions.\n";
    }
  }
  
  // Activity Analysis
  if (data.transactions && Array.isArray(data.transactions)) {
    const count = data.transactions.length;
    const totalSpent = data.transactions.reduce((sum: number, t: any) => sum + (parseFloat(t.amount) || 0), 0);
    
    insights += `* **Spending Velocity:** ${count} transactions totaling ₦${totalSpent.toLocaleString()}. `;
    if (count > 10) {
      insights += "You are a high-frequency user. You've unlocked 'Gold' tier rewards!\n";
    } else if (count > 3) {
      insights += "Your usage pattern is consistent.\n";
    } else {
      insights += "Your activity is light. Explore our betting or education payment services.\n";
    }
  }

  insights += "\n### 💡 Proactive Suggestions\n";
  
  // Proactive logic based on data patterns
  const hasElectricity = data.transactions?.some((t: any) => t.type === 'electricity');
  if (hasElectricity) {
    insights += "1. **Auto-Pay:** I noticed you pay electricity bills regularly. Enable 'Auto-Pay' in settings to never miss a due date.\n";
  } else {
    insights += "1. **Convenience:** Try our electricity bill payment service for instant token generation.\n";
  }
  
  insights += "2. **Budgeting:** Use sub-wallets to separate 'Essential' (Data/Power) from 'Discretionary' (Betting/TV) spending.\n";
  insights += "3. **Rewards:** Check your 'Rewards' dashboard; your consistent usage is nearing the next tier milestone.";
  
  return insights;
};
