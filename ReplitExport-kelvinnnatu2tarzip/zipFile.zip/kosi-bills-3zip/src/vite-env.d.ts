/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_FLW_PUBLIC_KEY: string;
  readonly GEMINI_API_KEY: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
