import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { Sparkles, Loader2, RefreshCw } from 'lucide-react';
import { analyzeDataLocally } from '../../services/aiInsightsService';

interface AIInsightsProps {
  context: string;
  data: any;
  title?: string;
}

export default function AIInsights({ context, data, title = "AI Insights" }: AIInsightsProps) {
  const [insights, setInsights] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const cache = useRef<Record<string, string>>({});

  const generateInsights = async (forceRefresh = false) => {
    const dataKey = JSON.stringify(data);
    if (!forceRefresh && cache.current[dataKey]) {
      setInsights(cache.current[dataKey]);
      return;
    }

    setIsLoading(true);
    setError(null);
    
    // Simulate "thinking"
    await new Promise(resolve => setTimeout(resolve, 1500));

    try {
      // Local analysis logic
      const analysis = analyzeDataLocally(data);
      cache.current[dataKey] = analysis;
      setInsights(analysis);
    } catch (err) {
      console.error('Error generating insights:', err);
      setError('Failed to generate insights. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (data && Object.keys(data).length > 0) {
      generateInsights();
    }
  }, [data]);

  return (
    <div className="bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20 rounded-2xl p-6 border border-indigo-100 dark:border-indigo-800/50 shadow-sm relative overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/10 dark:bg-purple-400/10 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />
      
      <div className="flex items-center justify-between mb-4 relative z-10">
        <div className="flex items-center gap-2 text-indigo-700 dark:text-indigo-400">
          <Sparkles className="w-5 h-5" />
          <h3 className="font-bold">{title}</h3>
        </div>
        <button 
          onClick={() => generateInsights(true)}
          disabled={isLoading}
          className="p-2 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-800/50 rounded-lg transition-colors disabled:opacity-50"
          title="Refresh Insights"
        >
          <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      <div className="relative z-10 text-sm text-slate-700 dark:text-slate-300">
        {isLoading ? (
          <div className="flex items-center gap-3 text-indigo-600 dark:text-indigo-400 py-4">
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>Analyzing data...</span>
          </div>
        ) : error ? (
          <div className="text-red-500 dark:text-red-400 py-2">{error}</div>
        ) : insights ? (
          <div className="prose prose-sm dark:prose-invert max-w-none prose-p:leading-relaxed prose-li:my-1">
            {insights.split('\n').map((line, i) => {
              if (line.startsWith('* ') || line.startsWith('- ')) {
                return <li key={i} className="ml-4 list-disc">{line.substring(2)}</li>;
              }
              if (line.trim() === '') return <br key={i} />;
              return <p key={i} className="mb-2">{line}</p>;
            })}
          </div>
        ) : (
          <div className="text-slate-500 dark:text-slate-400 italic py-2">
            Waiting for data to analyze...
          </div>
        )}
      </div>
    </div>
  );
}
