import { useState, useCallback } from 'react';
import { getAIInsight } from '../services/geminiService';
import { User } from '../types';

export function useAI(user: User | null) {
  const [messages, setMessages] = useState<{ role: 'user' | 'ai', content: string }[]>([
    { role: 'ai', content: "Hello! I'm Kosi, your AI financial assistant. How can I help you today?" }
  ]);
  const [isLoading, setIsLoading] = useState(false);

  const sendMessage = useCallback(async (message: string) => {
    if (!message.trim() || isLoading || !user) return;

    setMessages(prev => [...prev, { role: 'user', content: message }]);
    setIsLoading(true);

    try {
      // Fetch context (e.g., recent transactions)
      const response = await fetch(`/api/transactions/${user.id}`);
      const data = await response.json();
      
      // Only send the last 5 transactions to reduce token usage
      const recentTransactions = (data.transactions || []).slice(0, 5);
      
      const aiResponse = await getAIInsight(message, { recentTransactions });
      setMessages(prev => [...prev, { role: 'ai', content: aiResponse || "I'm having some trouble connecting right now." }]);
    } catch (error) {
      console.error("AI Error:", error);
      setMessages(prev => [...prev, { role: 'ai', content: "I'm having some trouble connecting right now. Please try again later." }]);
    } finally {
      setIsLoading(false);
    }
  }, [user, isLoading]);

  const clearMessages = useCallback(() => {
    setMessages([{ role: 'ai', content: "Hello! I'm Kosi, your AI financial assistant. How can I help you today?" }]);
  }, []);

  return {
    messages,
    isLoading,
    sendMessage,
    clearMessages
  };
}
