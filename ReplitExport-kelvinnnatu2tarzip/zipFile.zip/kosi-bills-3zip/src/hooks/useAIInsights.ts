import { useState, useEffect, useRef } from 'react';

export function useAIInsights(data: any) {
  const [insights, setInsights] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const cache = useRef<Record<string, string>>({});

  const generateInsights = async (forceRefresh = false) => {
    const dataKey = JSON.stringify(data);
    if (!forceRefresh && cache.current[dataKey]) {
      setInsights(cache.current[dataKey]);
      return;
    }

    setIsLoading(true);
    setError(null);
    
    // Simulate "thinking"
    await new Promise(resolve => setTimeout(resolve, 1500));

    try {
      // Local analysis logic
      const analysis = analyzeDataLocally(data);
      cache.current[dataKey] = analysis;
      setInsights(analysis);
    } catch (err) {
      console.error('Error generating insights:', err);
      setError('Failed to generate insights. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const analyzeDataLocally = (data: any) => {
    let insights = "### 📊 Financial Health & Trends\n\n";
    
    // Balance Analysis
    if (data.balance !== undefined) {
      const bal = parseFloat(data.balance);
      insights += `* **Current Liquidity:** ₦${bal.toLocaleString()}. `;
      if (bal > 50000) {
        insights += "Your liquidity is strong. You're well-positioned for upcoming expenses.\n";
      } else if (bal > 10000) {
        insights += "Your balance is stable. Keep an eye on your upcoming utility renewals.\n";
      } else {
        insights += "⚠️ **Alert:** Your balance is running low. Consider a top-up to avoid service disruptions.\n";
      }
    }
    
    // Activity Analysis
    if (data.transactions && Array.isArray(data.transactions)) {
      const count = data.transactions.length;
      const totalSpent = data.transactions.reduce((sum: number, t: any) => sum + (parseFloat(t.amount) || 0), 0);
      
      insights += `* **Spending Velocity:** ${count} transactions totaling ₦${totalSpent.toLocaleString()}. `;
      if (count > 10) {
        insights += "You are a high-frequency user. You've unlocked 'Gold' tier rewards!\n";
      } else if (count > 3) {
        insights += "Your usage pattern is consistent.\n";
      } else {
        insights += "Your activity is light. Explore our betting or education payment services.\n";
      }
    }

    insights += "\n### 💡 Proactive Suggestions\n";
    
    // Proactive logic based on data patterns
    const hasElectricity = data.transactions?.some((t: any) => t.type === 'electricity');
    if (hasElectricity) {
      insights += "1. **Auto-Pay:** I noticed you pay electricity bills regularly. Enable 'Auto-Pay' in settings to never miss a due date.\n";
    } else {
      insights += "1. **Convenience:** Try our electricity bill payment service for instant token generation.\n";
    }
    
    insights += "2. **Budgeting:** Use sub-wallets to separate 'Essential' (Data/Power) from 'Discretionary' (Betting/TV) spending.\n";
    insights += "3. **Rewards:** Check your 'Rewards' dashboard; your consistent usage is nearing the next tier milestone.";
    
    return insights;
  };

  useEffect(() => {
    if (data && Object.keys(data).length > 0) {
      generateInsights();
    }
  }, [data]);

  return {
    insights,
    isLoading,
    error,
    generateInsights
  };
}
