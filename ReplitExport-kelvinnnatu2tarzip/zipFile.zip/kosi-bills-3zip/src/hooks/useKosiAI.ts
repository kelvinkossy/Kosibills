import { useState, useRef, useEffect } from 'react';
import { getAIInsight } from '../services/geminiService';
import { User } from '../types';

export function useKosiAI(user: User | null) {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'ai', content: string }[]>([
    { role: 'ai', content: "Hello! I'm Kosi, your AI financial assistant. How can I help you today?" }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (e?: React.FormEvent, customMessage?: string) => {
    e?.preventDefault();
    const messageToSend = customMessage || input.trim();
    if (!messageToSend || isLoading || !user) return;

    const userMessage = messageToSend;
    if (!customMessage) setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsLoading(true);

    try {
      // Fetch context (e.g., recent transactions)
      const response = await fetch(`/api/transactions/${user.id}`);
      const data = await response.json();
      
      // Only send the last 5 transactions to reduce token usage
      const recentTransactions = (data.transactions || []).slice(0, 5);
      
      const aiResponse = await getAIInsight(userMessage, { recentTransactions });
      setMessages(prev => [...prev, { role: 'ai', content: aiResponse || "I'm having some trouble connecting right now." }]);
    } catch (error) {
      console.error("AI Error:", error);
      setMessages(prev => [...prev, { role: 'ai', content: "I'm having some trouble connecting right now. Please try again later." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return {
    isOpen,
    setIsOpen,
    isMinimized,
    setIsMinimized,
    messages,
    input,
    setInput,
    isLoading,
    messagesEndRef,
    handleSend
  };
}
